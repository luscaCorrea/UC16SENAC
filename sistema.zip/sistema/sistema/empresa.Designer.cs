﻿namespace sistema
{
    partial class empresa
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            txtTell = new MaskedTextBox();
            txtCNPJ = new MaskedTextBox();
            txtUF = new ComboBox();
            label10 = new Label();
            txtcod = new TextBox();
            txtobs = new TextBox();
            label9 = new Label();
            label7 = new Label();
            txtDiasTrabalhadosSemana = new TextBox();
            label6 = new Label();
            txtInscricaoEstadual = new TextBox();
            txtRazaoSocial = new TextBox();
            label5 = new Label();
            label13 = new Label();
            label11 = new Label();
            label8 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            txtemail = new TextBox();
            txtEndereco = new TextBox();
            txtNome = new TextBox();
            label1 = new Label();
            btnAlterar = new Button();
            btnLimpar = new Button();
            btnSair = new Button();
            btnExcluir = new Button();
            btnSalvar = new Button();
            groupBox2 = new GroupBox();
            btnpesquisa = new Button();
            Status = new Label();
            cboStatus = new ComboBox();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(txtTell);
            groupBox1.Controls.Add(txtCNPJ);
            groupBox1.Controls.Add(txtUF);
            groupBox1.Controls.Add(label10);
            groupBox1.Controls.Add(txtcod);
            groupBox1.Controls.Add(txtobs);
            groupBox1.Controls.Add(label9);
            groupBox1.Controls.Add(label7);
            groupBox1.Controls.Add(txtDiasTrabalhadosSemana);
            groupBox1.Controls.Add(label6);
            groupBox1.Controls.Add(txtInscricaoEstadual);
            groupBox1.Controls.Add(txtRazaoSocial);
            groupBox1.Controls.Add(label5);
            groupBox1.Controls.Add(label13);
            groupBox1.Controls.Add(label11);
            groupBox1.Controls.Add(label8);
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(txtemail);
            groupBox1.Controls.Add(txtEndereco);
            groupBox1.Controls.Add(txtNome);
            groupBox1.Controls.Add(label1);
            groupBox1.Location = new Point(12, 12);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(524, 347);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            // 
            // txtTell
            // 
            txtTell.Location = new Point(317, 95);
            txtTell.Mask = "(00) 00000-0000";
            txtTell.Name = "txtTell";
            txtTell.Size = new Size(88, 23);
            txtTell.TabIndex = 27;
            // 
            // txtCNPJ
            // 
            txtCNPJ.Location = new Point(366, 48);
            txtCNPJ.Mask = "000.000.000-00";
            txtCNPJ.Name = "txtCNPJ";
            txtCNPJ.Size = new Size(100, 23);
            txtCNPJ.TabIndex = 0;
            // 
            // txtUF
            // 
            txtUF.DropDownStyle = ComboBoxStyle.DropDownList;
            txtUF.FormattingEnabled = true;
            txtUF.Items.AddRange(new object[] { "AC", "", "AP", "", "AM", "", "PA", "", "RR", "", "TO", "AL", "", "BA", "", "CE", "", "MA", "", "PB", "", "PE", "", "PI", "", "RN", "", "SE", "DF", "", "GO", "", "MT", "", "MS", "ES", "", "MG", "", "RJ", "", "SP", "PR", "", "RS", "", "SC" });
            txtUF.Location = new Point(268, 95);
            txtUF.Name = "txtUF";
            txtUF.Size = new Size(43, 23);
            txtUF.TabIndex = 26;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(472, 30);
            label10.Name = "label10";
            label10.Size = new Size(46, 15);
            label10.TabIndex = 25;
            label10.Text = "Código";
            // 
            // txtcod
            // 
            txtcod.Location = new Point(472, 48);
            txtcod.Name = "txtcod";
            txtcod.ReadOnly = true;
            txtcod.Size = new Size(46, 23);
            txtcod.TabIndex = 24;
            // 
            // txtobs
            // 
            txtobs.Location = new Point(9, 209);
            txtobs.Multiline = true;
            txtobs.Name = "txtobs";
            txtobs.Size = new Size(506, 123);
            txtobs.TabIndex = 23;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(8, 191);
            label9.Name = "label9";
            label9.Size = new Size(74, 15);
            label9.TabIndex = 22;
            label9.Text = "Observações";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(375, 131);
            label7.Name = "label7";
            label7.Size = new Size(149, 15);
            label7.TabIndex = 21;
            label7.Text = "Dias trabalhados (semana):";
            // 
            // txtDiasTrabalhadosSemana
            // 
            txtDiasTrabalhadosSemana.Location = new Point(375, 149);
            txtDiasTrabalhadosSemana.Name = "txtDiasTrabalhadosSemana";
            txtDiasTrabalhadosSemana.Size = new Size(143, 23);
            txtDiasTrabalhadosSemana.TabIndex = 20;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(240, 131);
            label6.Name = "label6";
            label6.Size = new Size(101, 15);
            label6.TabIndex = 18;
            label6.Text = "Inscrição Estadual";
            // 
            // txtInscricaoEstadual
            // 
            txtInscricaoEstadual.Location = new Point(244, 149);
            txtInscricaoEstadual.Name = "txtInscricaoEstadual";
            txtInscricaoEstadual.Size = new Size(125, 23);
            txtInscricaoEstadual.TabIndex = 17;
            // 
            // txtRazaoSocial
            // 
            txtRazaoSocial.Location = new Point(8, 149);
            txtRazaoSocial.Name = "txtRazaoSocial";
            txtRazaoSocial.Size = new Size(230, 23);
            txtRazaoSocial.TabIndex = 16;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(6, 131);
            label5.Name = "label5";
            label5.Size = new Size(72, 15);
            label5.TabIndex = 15;
            label5.Text = "Razão Social";
            label5.Click += label5_Click;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(409, 77);
            label13.Name = "label13";
            label13.Size = new Size(41, 15);
            label13.TabIndex = 13;
            label13.Text = "E-mail";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(318, 77);
            label11.Name = "label11";
            label11.Size = new Size(51, 15);
            label11.TabIndex = 11;
            label11.Text = "Telefone";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(271, 77);
            label8.Name = "label8";
            label8.Size = new Size(21, 15);
            label8.TabIndex = 8;
            label8.Text = "UF";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(6, 77);
            label4.Name = "label4";
            label4.Size = new Size(56, 15);
            label4.TabIndex = 4;
            label4.Text = "Endereço";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(366, 30);
            label3.Name = "label3";
            label3.Size = new Size(34, 15);
            label3.TabIndex = 3;
            label3.Text = "CNPJ";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(6, 30);
            label2.Name = "label2";
            label2.Size = new Size(40, 15);
            label2.TabIndex = 2;
            label2.Text = "Nome";
            // 
            // txtemail
            // 
            txtemail.Location = new Point(411, 95);
            txtemail.Name = "txtemail";
            txtemail.Size = new Size(107, 23);
            txtemail.TabIndex = 1;
            // 
            // txtEndereco
            // 
            txtEndereco.Location = new Point(6, 95);
            txtEndereco.Name = "txtEndereco";
            txtEndereco.Size = new Size(259, 23);
            txtEndereco.TabIndex = 1;
            // 
            // txtNome
            // 
            txtNome.Location = new Point(6, 48);
            txtNome.Name = "txtNome";
            txtNome.Size = new Size(354, 23);
            txtNome.TabIndex = 1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(0, -3);
            label1.Name = "label1";
            label1.Size = new Size(67, 20);
            label1.TabIndex = 0;
            label1.Text = "Empresa";
            // 
            // btnAlterar
            // 
            btnAlterar.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold);
            btnAlterar.Location = new Point(243, 26);
            btnAlterar.Name = "btnAlterar";
            btnAlterar.Size = new Size(68, 34);
            btnAlterar.TabIndex = 15;
            btnAlterar.Text = "Alterar";
            btnAlterar.UseVisualStyleBackColor = true;
            btnAlterar.Click += btnAlterar_Click;
            // 
            // btnLimpar
            // 
            btnLimpar.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold);
            btnLimpar.Location = new Point(317, 26);
            btnLimpar.Name = "btnLimpar";
            btnLimpar.Size = new Size(69, 34);
            btnLimpar.TabIndex = 15;
            btnLimpar.Text = "Limpar";
            btnLimpar.UseVisualStyleBackColor = true;
            btnLimpar.Click += btnLimpar_Click;
            // 
            // btnSair
            // 
            btnSair.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold);
            btnSair.Location = new Point(455, 26);
            btnSair.Name = "btnSair";
            btnSair.Size = new Size(59, 34);
            btnSair.TabIndex = 15;
            btnSair.Text = "&Sair";
            btnSair.UseVisualStyleBackColor = true;
            btnSair.Click += btosair_Click;
            // 
            // btnExcluir
            // 
            btnExcluir.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold);
            btnExcluir.Location = new Point(390, 26);
            btnExcluir.Name = "btnExcluir";
            btnExcluir.Size = new Size(59, 34);
            btnExcluir.TabIndex = 15;
            btnExcluir.Text = "Excluir";
            btnExcluir.UseVisualStyleBackColor = true;
            btnExcluir.Click += btnExcluir_Click;
            // 
            // btnSalvar
            // 
            btnSalvar.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold);
            btnSalvar.Location = new Point(170, 26);
            btnSalvar.Name = "btnSalvar";
            btnSalvar.Size = new Size(67, 34);
            btnSalvar.TabIndex = 15;
            btnSalvar.Text = "Salvar";
            btnSalvar.UseVisualStyleBackColor = true;
            btnSalvar.Click += btnSalvar_Click;
            // 
            // groupBox2
            // 
            groupBox2.AccessibleRole = AccessibleRole.TitleBar;
            groupBox2.Controls.Add(btnpesquisa);
            groupBox2.Controls.Add(Status);
            groupBox2.Controls.Add(cboStatus);
            groupBox2.Controls.Add(btnExcluir);
            groupBox2.Controls.Add(btnSalvar);
            groupBox2.Controls.Add(btnAlterar);
            groupBox2.Controls.Add(btnSair);
            groupBox2.Controls.Add(btnLimpar);
            groupBox2.Location = new Point(12, 365);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(524, 78);
            groupBox2.TabIndex = 16;
            groupBox2.TabStop = false;
            // 
            // btnpesquisa
            // 
            btnpesquisa.Location = new Point(99, 26);
            btnpesquisa.Name = "btnpesquisa";
            btnpesquisa.Size = new Size(65, 34);
            btnpesquisa.TabIndex = 17;
            btnpesquisa.Text = "Pesquisar";
            btnpesquisa.UseVisualStyleBackColor = true;
            btnpesquisa.Click += btnpesquisa_Click_1;
            // 
            // Status
            // 
            Status.AutoSize = true;
            Status.Location = new Point(9, 15);
            Status.Name = "Status";
            Status.Size = new Size(39, 15);
            Status.TabIndex = 24;
            Status.Text = "Status";
            // 
            // cboStatus
            // 
            cboStatus.DropDownStyle = ComboBoxStyle.DropDownList;
            cboStatus.FormattingEnabled = true;
            cboStatus.Items.AddRange(new object[] { "ATIVO", "INATIVO" });
            cboStatus.Location = new Point(9, 33);
            cboStatus.Name = "cboStatus";
            cboStatus.Size = new Size(73, 23);
            cboStatus.TabIndex = 16;
            // 
            // empresa
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(542, 456);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Name = "empresa";
            Text = "Empresas";
            Load += empresa_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBox1;
        private Label label1;
        private Label label4;
        private Label label3;
        private Label label2;
        private TextBox txtEndereco;
        private TextBox txtNome;
        private Label label8;
        private Button btnSalvar;
        private Button btnExcluir;
        private Button btnSair;
        private Button btnLimpar;
        private Button btnAlterar;
        private Label label13;
        private Label label11;
        private TextBox txtemail;
        private GroupBox groupBox2;
        private Label label5;
        private Label label7;
        private TextBox txtDiasTrabalhadosSemana;
        private Label label6;
        private TextBox txtInscricaoEstadual;
        private TextBox txtRazaoSocial;
        private TextBox txtobs;
        private Label label9;
        private ComboBox cboStatus;
        private Label Status;
        private Label label10;
        private TextBox txtcod;
        private Button btnpesquisa;
        private ComboBox txtUF;
        private MaskedTextBox txtTell;
        private MaskedTextBox txtCNPJ;
    }
}
