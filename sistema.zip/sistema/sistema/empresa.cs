using System;
using System.Data;
using System.Data.SqlClient;


namespace sistema;

public partial class empresa : Form
{
    string stringConexao = "" + "Data Source=10.37.45.37;" + "Initial Catalog=sistema;" + "User ID=sa;" + "Password=123456";
    public empresa()
    {
        InitializeComponent();
    }




    private void TestarConexao()

    {
        SqlConnection conn = new SqlConnection(stringConexao);


        try
        {
            conn.Open();
            conn.Close();

        }
        catch (Exception ex)
        {

            MessageBox.Show("Erro: " + ex.ToString());
            Application.Exit();
        }




    }

    private void empresa_load(object sender, EventArgs e)
    {
        TestarConexao();
    }


    private void btosair_Click(object sender, EventArgs e)
    {
        Application.Exit();
    }

    private void label5_Click(object sender, EventArgs e)
    {

    }

    private void btnLimpar_Click(object sender, EventArgs e)
    {
        txtCNPJ.Text = "";
        txtDiasTrabalhadosSemana.Text = "";
        txtemail.Text = "";
        txtEndereco.Text = "";
        txtInscricaoEstadual.Text = "";
        txtNome.Text = "";
        txtobs.Text = "";
        txtRazaoSocial.Text = "";
        txtTell.Text = "";
        txtUF.Text = "";
        cboStatus.SelectedIndex = -1;
    }

    private void empresa_Load(object sender, EventArgs e)
    {

    }



    private void btnAlterar_Click(object sender, EventArgs e)
    {
        string sql = "update empresa set " +
            "nome_empresa='" + txtNome.Text + "'," +
            "cnpj_empresa='" + txtCNPJ.Text + "'," +
            "endereco_empresa='" + txtEndereco.Text + "'," +
            "telefone_empresa='" + txtTell.Text + "'," +
            "dias_trabalhados_na_semana_empresa='" + txtDiasTrabalhadosSemana.Text + "'," +
            "razao_social_empresa='" + txtRazaoSocial.Text + "'," +
            "uf_empresa='" + txtUF.Text + "'," +
            "inscri��o_estadual_empresa='" + txtInscricaoEstadual.Text + "'," +
            "obs_empresa='" + txtobs.Text + "'," +
            "status_empresa='" + cboStatus.Text + "'," +
            "where id_empresa=" + txtcod.Text;

        SqlConnection conexao = new SqlConnection(stringConexao);
        SqlCommand cmd = new SqlCommand(sql, conexao);
        cmd.CommandType = CommandType.Text;

        try
        {
            conexao.Open();
            int i = cmd.ExecuteNonQuery();
            if (i == 1)
            {
                MessageBox.Show("Dados alterados com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        catch (Exception ex)
        {

            MessageBox.Show(ex.ToString());
        }
        finally
        {
            conexao.Close();
        }

    }

    private void btnSalvar_Click(object sender, EventArgs e)
    {
        string sql = "insert into empresa(nome_empresa, cnpj_empresa, endereco_empresa, telefone_empresa, dias_trabalhados_na_semana_empresa, razao_social_empresa, uf_empresa, inscri��o_estadual_empresa, obs_empresa, status_empresa)values('" + txtNome.Text + "','" + txtCNPJ.Text + "','" + txtEndereco.Text + "','" + txtTell.Text + "','" + txtDiasTrabalhadosSemana.Text + "','" + txtRazaoSocial.Text + "','" + txtUF.Text + "','" + txtInscricaoEstadual.Text + "','" + txtobs.Text + "','" + cboStatus.Text + "')select SCOPE_IDENTITY()";
        SqlConnection conn = new SqlConnection(stringConexao);
        SqlCommand cmd = new SqlCommand(sql, conn);
        cmd.CommandType = CommandType.Text;
        SqlDataReader reader;
        conn.Open();

        try
        {
            reader = cmd.ExecuteReader();
            if (reader.Read())
            {
                MessageBox.Show("Cadastro realizado com sucesso", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtcod.Text = reader[0].ToString();

                //Limpar();
                //btopesquisar.performclick();

            }
        }
        catch (Exception ex)
        {

            MessageBox.Show("Erro: " + ex.ToString());
        }
        finally
        {
            conn.Close();
        }





    }

    private void btnpesquisa_Click(object sender, EventArgs e)
    {

    }

    private void btnExcluir_Click(object sender, EventArgs e)
    {
        string sql = "delete from empresa where id_empresa = " + txtcod.Text;

        SqlConnection conexao = new SqlConnection(stringConexao);
        SqlCommand cmd = new SqlCommand(sql, conexao);
        cmd.CommandType = CommandType.Text;


        try
        {
            conexao.Open();

            int i = cmd.ExecuteNonQuery();
            if (i == 1)
            {
                MessageBox.Show("Dados exclu�dos com sucesso.", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

        }
        catch (Exception ex)
        {

            MessageBox.Show(ex.ToString());
        }
        finally
        {
            conexao.Close();
        }
    }

    private void btnpesquisa_Click_1(object sender, EventArgs e)
    {

        string sql = "select * from empresa where id_empresa=" + txtcod.Text;

        SqlConnection conexao = new SqlConnection(stringConexao);
        SqlCommand cmd = new SqlCommand(sql, conexao);
        cmd.CommandType = CommandType.Text;
        SqlDataReader reader;
        conexao.Open();

        try
        {
            reader = cmd.ExecuteReader();
            if (reader.Read())
            {
                txtcod.Text = reader[0].ToString();
            }
            else
            {
                MessageBox.Show("C�digo do usu�rio inexistente!");
            }

        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.ToString());
        }
        finally
        {
            conexao.Close();
        }

    }
}

