﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace sistema

{


    public partial class setor : Form
    {
        string stringConexao = "" + "Data Source=10.37.45.37;" + "Initial Catalog=sistema;" + "User ID=sa;" + "Password=123456";

        private void TestarConexao()

        {
            SqlConnection conn = new SqlConnection(stringConexao);


            try
            {
                conn.Open();
                conn.Close();

            }
            catch (Exception ex)
            {

                MessageBox.Show("Erro: " + ex.ToString());
                Application.Exit();
            }

        }
        public setor()
        {
            InitializeComponent();
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            txtdesc.Text = "";
            txtNome.SelectedIndex = -1;
            cboStatus.SelectedIndex = -1;


        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            /*private void btnSalvar_Click(object sender, EventArgs e)
            {
                string sql = "insert into empresa(nome_empresa, cnpj_empresa, endereco_empresa, telefone_empresa, dias_trabalhados_na_semana_empresa, razao_social_empresa, uf_empresa, inscrição_estadual_empresa, obs_empresa, status_empresa)values('" +"')select SCOPE_IDENTITY()";
                SqlConnection conn = new SqlConnection(stringConexao);
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.CommandType = CommandType.Text;
                SqlDataReader reader;
                conn.Open();

                try
                {
                    reader = cmd.ExecuteReader();
                    if (reader.Read())
                    {
                        MessageBox.Show("Cadastro realizado com sucesso", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        txtcod.Text = reader[0].ToString();

                        //Limpar();
                        //btopesquisar.performclick();

                    }
                }
                catch (Exception ex)
                {

                    MessageBox.Show("Erro: " + ex.ToString());
                }
                finally
                {
                    conn.Close();
                }





            }*/
        }
    }
}
