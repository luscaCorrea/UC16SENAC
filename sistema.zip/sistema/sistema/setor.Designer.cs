﻿namespace sistema
{
    partial class setor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            txtNome = new ComboBox();
            label3 = new Label();
            cboStatus = new ComboBox();
            label2 = new Label();
            label1 = new Label();
            txtdesc = new TextBox();
            groupBox2 = new GroupBox();
            btnSalvar = new Button();
            btnAlterar = new Button();
            btnExcluir = new Button();
            btnLimpar = new Button();
            btnSair = new Button();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(txtNome);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(cboStatus);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(label1);
            groupBox1.Controls.Add(txtdesc);
            groupBox1.Location = new Point(12, 2);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(483, 231);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            // 
            // txtNome
            // 
            txtNome.DropDownStyle = ComboBoxStyle.DropDownList;
            txtNome.FormattingEnabled = true;
            txtNome.Items.AddRange(new object[] { "Tecnologia da Informação (TI)", "Saúde e Farmacêutico", "Financeiro e Bancário", "Varejo e Comércio Eletrônico", "Energia e Utilidades", "Automotivo", "Alimentos e Bebidas", "Agricultura e Agroindústria", "Construção e Imobiliário", "Telecomunicações", "Educação e Treinamento", "Mídia e Entretenimento", "Transporte e Logística", "Indústria Aeroespacial", "Turismo e Hospitalidade" });
            txtNome.Location = new Point(6, 37);
            txtNome.Name = "txtNome";
            txtNome.Size = new Size(332, 23);
            txtNome.TabIndex = 5;
            txtNome.SelectedIndexChanged += comboBox2_SelectedIndexChanged;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(344, 19);
            label3.Name = "label3";
            label3.Size = new Size(39, 15);
            label3.TabIndex = 4;
            label3.Text = "Status";
            // 
            // cboStatus
            // 
            cboStatus.DropDownStyle = ComboBoxStyle.DropDownList;
            cboStatus.FormattingEnabled = true;
            cboStatus.Items.AddRange(new object[] { "ATIVO", "INATIVO" });
            cboStatus.Location = new Point(344, 37);
            cboStatus.Name = "cboStatus";
            cboStatus.Size = new Size(127, 23);
            cboStatus.TabIndex = 3;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(6, 66);
            label2.Name = "label2";
            label2.Size = new Size(58, 15);
            label2.TabIndex = 2;
            label2.Text = "Descrição";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(6, 19);
            label1.Name = "label1";
            label1.Size = new Size(87, 15);
            label1.TabIndex = 1;
            label1.Text = "Nome do Setor";
            // 
            // txtdesc
            // 
            txtdesc.Location = new Point(6, 84);
            txtdesc.Multiline = true;
            txtdesc.Name = "txtdesc";
            txtdesc.Size = new Size(465, 132);
            txtdesc.TabIndex = 0;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(btnSalvar);
            groupBox2.Controls.Add(btnAlterar);
            groupBox2.Controls.Add(btnExcluir);
            groupBox2.Controls.Add(btnLimpar);
            groupBox2.Controls.Add(btnSair);
            groupBox2.Location = new Point(12, 239);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(483, 66);
            groupBox2.TabIndex = 1;
            groupBox2.TabStop = false;
            // 
            // btnSalvar
            // 
            btnSalvar.Location = new Point(115, 22);
            btnSalvar.Name = "btnSalvar";
            btnSalvar.Size = new Size(63, 28);
            btnSalvar.TabIndex = 0;
            btnSalvar.Text = "Salvar";
            btnSalvar.UseVisualStyleBackColor = true;
            btnSalvar.Click += btnSalvar_Click;
            // 
            // btnAlterar
            // 
            btnAlterar.Location = new Point(184, 22);
            btnAlterar.Name = "btnAlterar";
            btnAlterar.Size = new Size(65, 28);
            btnAlterar.TabIndex = 0;
            btnAlterar.Text = "Alterar";
            btnAlterar.UseVisualStyleBackColor = true;
            // 
            // btnExcluir
            // 
            btnExcluir.Location = new Point(255, 22);
            btnExcluir.Name = "btnExcluir";
            btnExcluir.Size = new Size(67, 28);
            btnExcluir.TabIndex = 0;
            btnExcluir.Text = "Excluir";
            btnExcluir.UseVisualStyleBackColor = true;
            // 
            // btnLimpar
            // 
            btnLimpar.Location = new Point(328, 22);
            btnLimpar.Name = "btnLimpar";
            btnLimpar.Size = new Size(70, 28);
            btnLimpar.TabIndex = 0;
            btnLimpar.Text = "Limpar";
            btnLimpar.UseVisualStyleBackColor = true;
            btnLimpar.Click += button2_Click;
            // 
            // btnSair
            // 
            btnSair.Location = new Point(404, 22);
            btnSair.Name = "btnSair";
            btnSair.Size = new Size(61, 28);
            btnSair.TabIndex = 0;
            btnSair.Text = "&Sair";
            btnSair.UseVisualStyleBackColor = true;
            btnSair.Click += button1_Click;
            // 
            // setor
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(499, 316);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Name = "setor";
            Text = "setor";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBox1;
        private GroupBox groupBox2;
        private TextBox txtdesc;
        private ComboBox txtNome;
        private Label label3;
        private ComboBox cboStatus;
        private Label label2;
        private Label label1;
        private Button btnSalvar;
        private Button btnAlterar;
        private Button btnExcluir;
        private Button btnLimpar;
        private Button btnSair;
    }
}