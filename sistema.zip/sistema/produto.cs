﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Data;
using System.Data.SqlClient;

namespace sistema
{
    public partial class produto : Form
    {
        public produto()
        {
            InitializeComponent();
        }

        string strConexao = "" +
               "Data Source=localhost;" +
               "Initial Catalog=sistema;" +
               "User ID=sa;" +
               "Password=123456";

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void conexao()
        {
            SqlConnection conn = new SqlConnection(strConexao);

            try
            {
                conn.Open();
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro " + ex.ToString());
                Application.Exit();
            }
        }
        //private void txtDescricao_TextChanged(object sender, EventArgs e)
        private void textBox6_TextChanged(object sender, EventArgs e)
        //private void txtDescricao_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtNome_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtCustoPedido_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtCustoAquisicao_TextChanged(object sender, EventArgs e)
        {

        }

        //private void txtPcAquisicao_TextChanged(object sender, EventArgs e)
        private void txPcAquisicao_TextChanged(object sender, EventArgs e)
        //private void txtPcAquisicao_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtCa_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtPcArmazenagem_TextChanged(object sender, EventArgs e)
        {

        }

        private void cboIdCategoria_SelectedIndexChanged(object sender, EventArgs e)
        {
            CarregarComboCAT();
        }

        void CarregarComboCAT()
        {
            string sql = "select id_categoria, nome_categoria from categoria";

            SqlConnection conexao = new SqlConnection(strConexao);
            SqlCommand cmd = new SqlCommand(sql, conexao);
            cmd.CommandType = CommandType.Text;
            SqlDataReader reader;

            DataTable tabela = new DataTable();

            conexao.Open();

         


            try
            {
                reader = cmd.ExecuteReader();

                tabela.Load(reader);

                cboValorCat.DisplayMember = "id_categoria";
                cboValorCat.DataSource = tabela;

                cboIdCategoria.DisplayMember = "nome_categoria";
                cboIdCategoria.DataSource = tabela;


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                Application.Exit();

            }
            finally
            {
                conexao.Close();
            }
        }


        private void cboIdNivelServico_SelectedIndexChanged(object sender, EventArgs e)
        {
            CarregarComboNV();
        }

        void CarregarComboNV()
        {
            string sql = "select id_nivel_servico, percentual_nivel_servico from nivel_de_servico";

            SqlConnection conexao = new SqlConnection(strConexao);
            SqlCommand cmd = new SqlCommand(sql, conexao);
            cmd.CommandType = CommandType.Text;
            SqlDataReader reader;

            DataTable tabela = new DataTable();

            conexao.Open();

            try
            {
                reader = cmd.ExecuteReader();

                tabela.Load(reader);

                cbValorNV.DisplayMember = "id_nivel_servico";
                cbValorNV.DataSource = tabela;

                cboIdNivelServico.DisplayMember = "percentual_nivel_servico";
                cboIdNivelServico.DataSource = tabela;


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                Application.Exit();

            }
            finally
            {
                conexao.Close();
            }
        }

        private void cboIdFornecedor_SelectedIndexChanged(object sender, EventArgs e)
        {
            CarregarCombo();
        }

        void CarregarCombo()
        {
            string sql = "select id_fornecedor, nome_fornecedor from fornecedor";

            SqlConnection conexao = new SqlConnection(strConexao);
            SqlCommand cmd = new SqlCommand(sql, conexao);
            cmd.CommandType = CommandType.Text;
            SqlDataReader reader;

            DataTable tabela = new DataTable();

            conexao.Open();

            try
            {
                reader = cmd.ExecuteReader();

                tabela.Load(reader);
                cbValorFornecedor.DisplayMember = "id_fornecedor";
                cbValorFornecedor.DataSource = tabela;

                cboIdFornecedor.DisplayMember = "nome_fornecedor";
                cboIdFornecedor.DataSource = tabela;
                
                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                Application.Exit();

            }
            finally
            {
                conexao.Close();
            }
        }

       

        private void txtObs_TextChanged(object sender, EventArgs e)
        {

        }

        private void cboStatus_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            if (ValidarDados() == false)
            {
                return;
            }

            string sql = "insert into produto" +
                "(" +
                    "nome_produto," +
                    "descricao_produto," +
                    "custo_de_pedido_produto," +
                    "custo_de_aquisicao_produto," +
                    "percentual_de_custo_de_aquisicao_produto," +
                    "custo_de_armazenagem_produto," +
                    "percentual_de_custo_de_armazenagem_produto," +
                    "obs_produto," +
                    "status_produto," +
                    "id_categoria, " +
                    "id_nivel_servico, " +
                    "id_fornecedor " +

                ")" +
                "values" +
                "(" +
                    "'" + txtNome.Text + "'," +
                    "'" + txtDescricao.Text + "'," +
                    "'" + txtCustoPedido.Text + "'," +
                    "'" + txtCustoAquisicao.Text + "'," +
                    "'" + txtPcAquisicao.Text + "'," +
                    "'" + txtCa.Text + "'," +
                    "'" + txtPcArmazenagem.Text + "'," +
                    "'" + txtObs.Text + "'," +
                    "'" + cboStatus.Text + "'," +
                    "'" + cboValorCat.Text + "'," +
                    "'" + cbValorNV.Text + "', " +
                    "'" + cbValorFornecedor.Text + "'" +

                ")select SCOPE_IDENTITY()";

            SqlConnection conexao = new SqlConnection(strConexao);
            SqlCommand cmd = new SqlCommand(sql, conexao);
            cmd.CommandType = CommandType.Text;
            SqlDataReader reader;
            conexao.Open();

            try
            {
                reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    MessageBox.Show("Cadastro realizado com sucesso");

                    btnLimpar.PerformClick();
                    txtId.Text = reader[0].ToString();
                    btnPesquisar.PerformClick();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());

            }
            finally
            {
                conexao.Close();
            }
        }

        private void btnAlterar_Click(object sender, EventArgs e)
        {
            if (ValidarDados() == false)
            {
                return;
            }

            string sql = "update produto set " +
               "nome_produto = '" + txtNome.Text + "'," +
               "descricao_produto = '" + txtDescricao.Text + "', " +
               "custo_de_pedido_produto = '" + txtCustoPedido.Text + "', " +
               "custo_de_aquisicao_produto = '" + txtCustoAquisicao.Text + "', " +
               "percentual_de_custo_de_aquisicao_produto = '" + txtPcAquisicao.Text + "', " +
               "custo_de_armazenagem_produto = '" + txtCa.Text + "', " +
               "percentual_de_custo_de_armazenagem_produto ='" + txtPcArmazenagem.Text + "', " +
               "obs_produto = '" + txtObs.Text + "', " +
               "status_fornecedor = '" + cboStatus.Text + "', " +
               "id_categoria = '" + cboIdCategoria.Text + "', " +
               "id_nivel_servico = '" + cboIdNivelServico.Text + "', " +
               "id_fornecedor = '" + cboIdFornecedor.Text + "', " +

               "where id_fornecedor = " + txtId.Text;

            SqlConnection conn = new SqlConnection(strConexao);
            SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.CommandType = CommandType.Text;

            try
            {
                conn.Open();

                int i = cmd.ExecuteNonQuery();
                if (i == 1)
                {
                    MessageBox.Show("Alteração feita com sucesso");

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro: " + ex.ToString());
            }
            finally
            {
                conn.Close();
            }
        }

        private void btnPesquisar_Click(object sender, EventArgs e)
        {
            

            string sql = "select * from produto where id_produto =" + txtId.Text;

            SqlConnection conexao = new SqlConnection(strConexao);
            SqlCommand cmd = new SqlCommand(sql, conexao);
            cmd.CommandType = CommandType.Text;
            SqlDataReader reader;
            conexao.Open();

            try
            {
                reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    txtId.Text = reader[0].ToString();
                    txtNome.Text = reader[1].ToString();
                    txtDescricao.Text = reader[2].ToString();
                    txtCustoPedido.Text = reader[3].ToString();
                    txtCustoAquisicao.Text = reader[4].ToString();
                    txtPcAquisicao.Text = reader[5].ToString();
                    txtCa.Text = reader[6].ToString();
                    txtPcArmazenagem.Text = reader[7].ToString();
                    cboStatus.Text = reader[8].ToString();
                    txtObs.Text = reader[9].ToString();
                    cboIdFornecedor.Text = reader[10].ToString();
                    cboIdCategoria.Text = reader[11].ToString();
                    cboIdNivelServico.Text = reader[12].ToString();
                }
                else
                {
                    MessageBox.Show("Código do usuario inexistente!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                conexao.Close();
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtId.Text = "";
            txtNome.Text = "";
            txtCustoPedido.Text = "";
            txtCustoAquisicao.Text = "";
            txtPcAquisicao.Text = "";
            txtCa.Text = "";
            txtPcArmazenagem.Text = "";
            cboStatus.Text = "";
            txtObs.Text = "";
            cboIdFornecedor.Text ="";
            cboIdCategoria.Text = "";
            cboIdNivelServico.Text ="";
            txtDescricao.Text = "";
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            string sql = "delete from produto where id_produto = " + txtId.Text;
            SqlConnection conn = new SqlConnection(strConexao);
            SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.CommandType = CommandType.Text;

            try
            {
                conn.Open();

                int i = cmd.ExecuteNonQuery();
                if (i > 0)
                {
                    MessageBox.Show("Cadastro excluido sucesso");
                    btnLimpar.PerformClick();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro: " + ex.ToString);

            }
            finally
            {
                conn.Close();
            }
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            this.Close();

        }

        private void produto_Load(object sender, EventArgs e)
        {
            conexao();
            CarregarCombo();
            CarregarComboCAT();
            CarregarComboNV();


        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        //private void txtId_TextChanged(object sender, EventArgs e)

        private void textBox1_TextChanged(object sender, EventArgs e)
        //private void txtId_TextChanged(object sender, EventArgs e)
        {

        }

        int n1;
        private bool ValidarDados()
        {
            if (int.TryParse(txtNome.Text, out n1) == true)
            {
                MessageBox.Show("Campo deve conter nome");
                txtNome.Text = "";
                txtNome.Focus();
                return false;
            }

            if (txtNome.Text == "")
            {
                MessageBox.Show("Campo deve ser preenchido!");
                txtNome.Text = "";
                txtNome.Focus();
                return false;
            }

            /////////////////////////////////////////////////////////////////////////////////////////
            ///

            if (int.TryParse(txtDescricao.Text, out n1) == true)
            {
                MessageBox.Show("Campo deve conter descrição");
                txtDescricao.Text = "";
                txtDescricao.Focus();
                return false;
            }

            if (txtDescricao.Text == "")
            {
                MessageBox.Show("Campo deve ser preenchido");
                txtDescricao.Text = "";
                txtDescricao.Focus();
                return false;
            }

            /////////////////////////////////////////////////////////////////////////////////////////

            if (int.TryParse(txtCustoPedido.Text, out n1) == false)
            {
                MessageBox.Show("Campo deve conter custo pedido");
                txtCustoPedido.Text = "";
                txtCustoPedido.Focus();
                return false;
            }

            if (txtCustoPedido.Text == "")
            {
                MessageBox.Show("Campo deve ser preenchido");
                txtCustoPedido.Text = "";
                txtCustoPedido.Focus();
                return false;
            }

            /////////////////////////////////////////////////////////////////////////////////////////
            ///

            if (int.TryParse(txtCustoAquisicao.Text, out n1) == false)
            {
                MessageBox.Show("Campo deve conter custo aquisição");
                txtCustoAquisicao.Text = "";
                txtCustoAquisicao.Focus();
                return false;
            }

            if (txtCustoAquisicao.Text == "")
            {
                MessageBox.Show("Campo deve ser preenchido");
                txtCustoAquisicao.Text = "";
                txtCustoAquisicao.Focus();
                return false;
            }

            /////////////////////////////////////////////////////////////////////////////////////////
            ///
            
            if (int.TryParse(txtPcAquisicao.Text, out n1) == false)
            {
                MessageBox.Show("Campo deve conter custo aquisição");
                txtPcAquisicao.Text = "";
                txtPcAquisicao.Focus();
                return false;
            }

            if (txtPcAquisicao.Text == "")
            {
                MessageBox.Show("Campo deve conter custo aquisição");
                txtPcAquisicao.Text = "";
                txtPcAquisicao.Focus();
                return false;
            }

            /////////////////////////////////////////////////////////////////////////////////////////
            ///

            if (int.TryParse(txtPcAquisicao.Text, out n1) == false)
            {
                MessageBox.Show("Campo deve conter percentual de custo de aquisição");
                txtPcAquisicao.Text = "";
                txtPcAquisicao.Focus();
                return false;
            }

            if (txtPcAquisicao.Text == "")
            {
                MessageBox.Show("Campo deve ser preenchido");
                txtPcAquisicao.Text = "";
                txtPcAquisicao.Focus();
                return false;
            }

            /////////////////////////////////////////////////////////////////////////////////////////
            ///

            if (int.TryParse(txtCa.Text, out n1) == false)
            {
                MessageBox.Show("Campo deve conter custo aquisição");
                txtCa.Text = "";
                txtCa.Focus();
                return false;
            }

            if (txtCa.Text == "")
            {
                MessageBox.Show("Campo deve ser preenchido");
                txtCa.Text = "";
                txtCa.Focus();
                return false;
            }

            /////////////////////////////////////////////////////////////////////////////////////////
            ///

            if (int.TryParse(txtPcArmazenagem.Text, out n1) == false)
            {
                MessageBox.Show("Campo deve conter percentual de custo de armazenagem");
                txtPcArmazenagem.Text = "";
                txtPcArmazenagem.Focus();
                return false;
            }

            if (txtPcArmazenagem.Text == "")
            {
                MessageBox.Show("Campo deve ser preenchido");
                txtPcArmazenagem.Text = "";
                txtPcArmazenagem.Focus();
                return false;
            }

            /////////////////////////////////////////////////////////////////////////////////////////
            ///

            if (cboIdFornecedor.Text == "")
            {
                MessageBox.Show("Campo deve ser preenchido");
                cboIdFornecedor.Text = "";
                cboIdFornecedor.Focus();
                return false;
            }

            return true;
        }

        private void cboValorCat_SelectedIndexChanged(object sender, EventArgs e)
        {
            CarregarComboCAT();
        }

        private void cbValorNV_SelectedIndexChanged(object sender, EventArgs e)
        {
            CarregarComboNV();
        }

        private void cbValorFornecedor_SelectedIndexChanged(object sender, EventArgs e)
        {
            CarregarCombo();
        }
    }
}
