﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Data;
using System.Data.SqlClient;

namespace sistema
{
    public partial class parametroEstoque : Form
    {
        public parametroEstoque()
        {
            InitializeComponent();
        }

        string strConexao = "" +
                "Data Source=localhost;" +
                "Initial Catalog=sistema;" +
                "User ID=sa;" +
                "Password=123456";

        private void textBox8_TextChanged(object sender, EventArgs e)
        {

        }

        private void conexao()
        {
            SqlConnection conn = new SqlConnection(strConexao);

            try
            {
                conn.Open();
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro " + ex.ToString());
                Application.Exit();
            }
        }

        


        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void txtLec_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            string sql = "insert into fornecedor" +
                 "(" +
                    "id_produto, " +
                     "estoque_de_seguranca_parametro_de_estoque," +
                     "estoque_maximo_parametro_de_estoque," +
                     "estoque_medio_parametro_de_estoque," +
                     "ponto_de_pedido_parametro_de_estoque," +
                     "intervalo_entre_pedido_parametro_de_estoque," +
                     "intervalo_de_tempo_parametro_de_estoque," +
                     "lote_economico_de_compra_parametro_de_estoque," +
                     "obs_parametro_de_estoque," +
                     "status_parametro_de_estoque," +
                 ")" +
                 "values" +
                 "(" +
                     "'"+ cboIdProduto.Text +"', " +
                     "'" + txtEstoqueSeguranca.Text + "'," +
                     "'" + txtEstoqueMaximo.Text + "'," +
                     "'" + txtEstoqueMedio.Text + "'," +
                     "'" + txtPontoPedido.Text + "'," +
                     "'" + txtIntervaloPedido.Text + "'," +
                     "'" + txtIntervaloTempo.Text + "'," +
                     "'" + txtLec.Text + "'," +
                     "'" + txtObs.Text + "'," +
                     "'" + cboStatus.Text + "'" +
                 ")select SCOPE_IDENTITY()";

            SqlConnection conexao = new SqlConnection(strConexao);
            SqlCommand cmd = new SqlCommand(sql, conexao);
            cmd.CommandType = CommandType.Text;
            SqlDataReader reader;
            conexao.Open();

            try
            {
                reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    MessageBox.Show("Cadastro realizado com sucesso");

                    btnLimpar.PerformClick();
                    txtId.Text = reader[0].ToString();
                    btnPesquisar.PerformClick();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());

            }
            finally
            {
                conexao.Close();
            }
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnPesquisar_Click(object sender, EventArgs e)
        {
    
            string sql = "select * from parametro_de_estoque where id_parametro =" + txtId.Text;

            SqlConnection conexao = new SqlConnection(strConexao);
            SqlCommand cmd = new SqlCommand(sql, conexao);
            cmd.CommandType = CommandType.Text;
            SqlDataReader reader;
            conexao.Open();

            try
            {
                reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    txtId.Text = reader[0].ToString();
                    cboIdProduto.Text = reader[1].ToString();
                    txtEstoqueSeguranca.Text = reader[2].ToString();
                    txtEstoqueMaximo.Text = reader[3].ToString();
                    txtEstoqueMedio.Text = reader[4].ToString();
                    txtPontoPedido.Text = reader[5].ToString();
                    txtIntervaloPedido.Text = reader[6].ToString();
                    txtIntervaloTempo.Text = reader[7].ToString();
                    txtLec.Text = reader[8].ToString();
                    txtObs.Text = reader[9].ToString();
                    cboStatus.Text = reader[10].ToString();
                    
                }
                else
                {
                    MessageBox.Show("Código do usuario inexistente!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                conexao.Close();
            }

        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            string sql = "delete from fornecedor where id_fornecedor = " + txtId.Text;
            SqlConnection conn = new SqlConnection(strConexao);
            SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.CommandType = CommandType.Text;

            try
            {
                conn.Open();

                int i = cmd.ExecuteNonQuery();
                if (i > 0)
                {
                    MessageBox.Show("Cadastro excluido sucesso");
                    btnLimpar.PerformClick();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro: " + ex.ToString);

            }
            finally
            {
                conn.Close();
            }
        }

        //private void parametroEstoque(object sender, EventArgs e)
        private void Form1_Load(object sender, EventArgs e)
        //private void parametroEstoque(object sender, EventArgs e)
        {
            conexao();
            CarregarCombo();

        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtId.Text = "";
            cboIdProduto.Text = "";
            txtEstoqueSeguranca.Text = "";
            txtEstoqueMaximo.Text = "";
            txtEstoqueMedio.Text = "";
            txtIntervaloTempo.Text = "";
            txtIntervaloPedido.Text = "";
            txtLec.Text = "";
            txtObs.Text = "";
            cboStatus.Text = "";
            txtPontoPedido.Text = "";


        }

        private void btnExcluir_Click_1(object sender, EventArgs e)
        {
            string sql = "delete from parametro_de_estoque where id_parametro =" + txtId.Text;
            SqlConnection conn = new SqlConnection(strConexao);
            SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.CommandType = CommandType.Text;

            try
            {
                conn.Open();

                int i = cmd.ExecuteNonQuery();
                if (i > 0)
                {
                    MessageBox.Show("Cadastro excluido sucesso");
                    btnLimpar.PerformClick();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro: " + ex.ToString);

            }
            finally
            {
                conn.Close();
            }
        }

        private void btnAlterar_Click(object sender, EventArgs e)
        {
            string sql = "update fornecedor set " +
               "id_produto = '" + cboIdProduto.Text + "', " +
               "estoque_de_seguranca_parametro_de_estoque = '" + txtEstoqueSeguranca.Text + "'," +
               "estoque_maximo_parametro_de_estoque = '" + txtEstoqueMaximo.Text + "', " +
               "estoque_medio_parametro_de_estoque = '" + txtEstoqueMedio.Text + "', " +
               "ponto_de_pedido_parametro_de_estoque = '" + txtPontoPedido.Text + "', " +
               "intervalo_entre_pedido_parametro_de_estoque = '" + txtIntervaloPedido.Text + "', " +
               "intervalo_de_tempo_parametro_de_estoque = '" + txtIntervaloTempo.Text + "', " +
               "lote_economico_de_compra_parametro_de_estoque ='" + txtLec.Text + "', " +
               "obs_parametro_de_estoque = '" + txtObs.Text + "', " +
               "status_parametro_de_estoque = '" + txtObs.Text + "' " +
               "where id_parametro = " + txtId.Text;


            SqlConnection conn = new SqlConnection(strConexao);
            SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.CommandType = CommandType.Text;

            try
            {
                conn.Open();

                int i = cmd.ExecuteNonQuery();
                if (i == 1)
                {
                    MessageBox.Show("Alteração feita com sucesso");

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro: " + ex.ToString());
            }
            finally
            {
                conn.Close();
            }
        }

        private void txtPontoPedido_TextChanged(object sender, EventArgs e)
        {

        }

        private void cboIdProduto_SelectedIndexChanged(object sender, EventArgs e)
        {
            CarregarCombo();
        }

        void CarregarCombo()
        {
            string sql = "select id_produto, nome_produto from produto";

            SqlConnection conexao = new SqlConnection(strConexao);
            SqlCommand cmd = new SqlCommand(sql, conexao);
            cmd.CommandType = CommandType.Text;
            SqlDataReader reader;

            DataTable tabela = new DataTable();

            conexao.Open();

            try
            {
                reader = cmd.ExecuteReader();

                tabela.Load(reader);
                cbValorProduto.DisplayMember = "id_produto";
                cbValorProduto.DataSource = tabela;

                cboIdProduto.DisplayMember = "nome_produto";
                cboIdProduto.DataSource = tabela;


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                Application.Exit();

            }
            finally
            {
                conexao.Close();
            }
        }
    }
}
