﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sistema
{
    public partial class mdiPrejeto : Form
    {
        private int childFormNumber = 0;

        public mdiPrejeto()
        {
            InitializeComponent();
        }

   

        private void fornecedorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fornecedor frm = new fornecedor();
            frm.MdiParent = this;
            frm.Show();
        }

        private void produtoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            produto frm = new produto();
            frm.MdiParent = this;
            frm.Show();
        }

        private void parametroEstoqueToolStripMenuItem_Click(object sender, EventArgs e)
        {
            parametroEstoque frm = new parametroEstoque();
            frm.MdiParent = this;
            frm.Show();
        }

        private void categoriaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmCategoria frm = new frmCategoria();
            frm.MdiParent = this;
            frm.Show();
        }

        private void nivelDeServiçoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmNiveldeServico frm = new FrmNiveldeServico();
            frm.MdiParent = this;
            frm.Show();
        }
    }
}
