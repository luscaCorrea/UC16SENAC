namespace sistemaLogin
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            if (txtNome.Text == "admin" && txtSenha.Text == "123")
            {
                MessageBox.Show("Seja bem vindo");
                this.Close();
            }
            else
            {
                MessageBox.Show("Usu�rio ou senha inv�lida", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {


        }
    }
}