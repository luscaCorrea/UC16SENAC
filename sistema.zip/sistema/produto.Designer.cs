﻿namespace sistema
{
    partial class produto
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtId = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtPcArmazenagem = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtCa = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtPcAquisicao = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtCustoAquisicao = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtCustoPedido = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.cbValorFornecedor = new System.Windows.Forms.ComboBox();
            this.cbValorNV = new System.Windows.Forms.ComboBox();
            this.cboValorCat = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.cboStatus = new System.Windows.Forms.ComboBox();
            this.txtObs = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtDescricao = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.cboIdFornecedor = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.cboIdNivelServico = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.cboIdCategoria = new System.Windows.Forms.ComboBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btnFechar = new System.Windows.Forms.Button();
            this.btnExcluir = new System.Windows.Forms.Button();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.btnPesquisar = new System.Windows.Forms.Button();
            this.btnAlterar = new System.Windows.Forms.Button();
            this.btnSalvar = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtId);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.txtPcArmazenagem);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.txtCa);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.txtPcAquisicao);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.txtCustoAquisicao);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.txtCustoPedido);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.txtNome);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(879, 175);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Produto";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // txtId
            // 
            this.txtId.Location = new System.Drawing.Point(742, 41);
            this.txtId.Name = "txtId";
            this.txtId.Size = new System.Drawing.Size(114, 29);
            this.txtId.TabIndex = 13;
            this.txtId.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(710, 44);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(26, 21);
            this.label13.TabIndex = 12;
            this.label13.Text = "ID";
            // 
            // txtPcArmazenagem
            // 
            this.txtPcArmazenagem.Location = new System.Drawing.Point(690, 123);
            this.txtPcArmazenagem.Name = "txtPcArmazenagem";
            this.txtPcArmazenagem.Size = new System.Drawing.Size(166, 29);
            this.txtPcArmazenagem.TabIndex = 6;
            this.txtPcArmazenagem.TextChanged += new System.EventHandler(this.txtPcArmazenagem_TextChanged);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(397, 123);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(287, 21);
            this.label12.TabIndex = 10;
            this.label12.Text = "Percentual de Custo de Armazenagem";
            // 
            // txtCa
            // 
            this.txtCa.Location = new System.Drawing.Point(205, 120);
            this.txtCa.Name = "txtCa";
            this.txtCa.Size = new System.Drawing.Size(186, 29);
            this.txtCa.TabIndex = 5;
            this.txtCa.TextChanged += new System.EventHandler(this.txtCa_TextChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(15, 123);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(184, 21);
            this.label5.TabIndex = 8;
            this.label5.Text = "Custo de Armazenagem";
            // 
            // txtPcAquisicao
            // 
            this.txtPcAquisicao.Location = new System.Drawing.Point(606, 79);
            this.txtPcAquisicao.Name = "txtPcAquisicao";
            this.txtPcAquisicao.Size = new System.Drawing.Size(250, 29);
            this.txtPcAquisicao.TabIndex = 4;
            this.txtPcAquisicao.TextChanged += new System.EventHandler(this.txPcAquisicao_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(347, 82);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(253, 21);
            this.label4.TabIndex = 6;
            this.label4.Text = "Percentual de Custo de Aquisição";
            // 
            // txtCustoAquisicao
            // 
            this.txtCustoAquisicao.Location = new System.Drawing.Point(163, 79);
            this.txtCustoAquisicao.Name = "txtCustoAquisicao";
            this.txtCustoAquisicao.Size = new System.Drawing.Size(178, 29);
            this.txtCustoAquisicao.TabIndex = 3;
            this.txtCustoAquisicao.TextChanged += new System.EventHandler(this.txtCustoAquisicao_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(15, 82);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(147, 21);
            this.label3.TabIndex = 4;
            this.label3.Text = "Custo de aquisição";
            // 
            // txtCustoPedido
            // 
            this.txtCustoPedido.Location = new System.Drawing.Point(463, 41);
            this.txtCustoPedido.Name = "txtCustoPedido";
            this.txtCustoPedido.Size = new System.Drawing.Size(200, 29);
            this.txtCustoPedido.TabIndex = 2;
            this.txtCustoPedido.TextChanged += new System.EventHandler(this.txtCustoPedido_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(321, 44);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(136, 21);
            this.label2.TabIndex = 2;
            this.label2.Text = "Custo de pedido ";
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(76, 41);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(239, 29);
            this.txtNome.TabIndex = 1;
            this.txtNome.TextChanged += new System.EventHandler(this.txtNome_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(15, 44);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 21);
            this.label1.TabIndex = 0;
            this.label1.Text = "Nome";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.cbValorFornecedor);
            this.groupBox2.Controls.Add(this.cbValorNV);
            this.groupBox2.Controls.Add(this.cboValorCat);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.cboStatus);
            this.groupBox2.Controls.Add(this.txtObs);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.txtDescricao);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.cboIdFornecedor);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.cboIdNivelServico);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.cboIdCategoria);
            this.groupBox2.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.groupBox2.Location = new System.Drawing.Point(12, 193);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(892, 438);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            // 
            // cbValorFornecedor
            // 
            this.cbValorFornecedor.FormattingEnabled = true;
            this.cbValorFornecedor.Location = new System.Drawing.Point(665, 175);
            this.cbValorFornecedor.Name = "cbValorFornecedor";
            this.cbValorFornecedor.Size = new System.Drawing.Size(227, 28);
            this.cbValorFornecedor.TabIndex = 21;
            this.cbValorFornecedor.Visible = false;
            this.cbValorFornecedor.SelectedIndexChanged += new System.EventHandler(this.cbValorFornecedor_SelectedIndexChanged);
            // 
            // cbValorNV
            // 
            this.cbValorNV.FormattingEnabled = true;
            this.cbValorNV.Location = new System.Drawing.Point(665, 121);
            this.cbValorNV.Name = "cbValorNV";
            this.cbValorNV.Size = new System.Drawing.Size(227, 28);
            this.cbValorNV.TabIndex = 20;
            this.cbValorNV.Visible = false;
            this.cbValorNV.SelectedIndexChanged += new System.EventHandler(this.cbValorNV_SelectedIndexChanged);
            // 
            // cboValorCat
            // 
            this.cboValorCat.FormattingEnabled = true;
            this.cboValorCat.Location = new System.Drawing.Point(665, 56);
            this.cboValorCat.Name = "cboValorCat";
            this.cboValorCat.Size = new System.Drawing.Size(227, 28);
            this.cboValorCat.TabIndex = 19;
            this.cboValorCat.Visible = false;
            this.cboValorCat.SelectedIndexChanged += new System.EventHandler(this.cboValorCat_SelectedIndexChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(686, 276);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(50, 20);
            this.label11.TabIndex = 18;
            this.label11.Text = "Status";
            // 
            // cboStatus
            // 
            this.cboStatus.FormattingEnabled = true;
            this.cboStatus.Items.AddRange(new object[] {
            "ATIVO\t",
            "INATIVO"});
            this.cboStatus.Location = new System.Drawing.Point(686, 299);
            this.cboStatus.Name = "cboStatus";
            this.cboStatus.Size = new System.Drawing.Size(182, 28);
            this.cboStatus.TabIndex = 10;
            this.cboStatus.SelectedIndexChanged += new System.EventHandler(this.cboStatus_SelectedIndexChanged);
            // 
            // txtObs
            // 
            this.txtObs.Location = new System.Drawing.Point(98, 246);
            this.txtObs.Multiline = true;
            this.txtObs.Name = "txtObs";
            this.txtObs.Size = new System.Drawing.Size(548, 169);
            this.txtObs.TabIndex = 11;
            this.txtObs.TextChanged += new System.EventHandler(this.txtObs_TextChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(6, 246);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(90, 20);
            this.label10.TabIndex = 15;
            this.label10.Text = "Observação";
            // 
            // txtDescricao
            // 
            this.txtDescricao.Location = new System.Drawing.Point(98, 34);
            this.txtDescricao.Multiline = true;
            this.txtDescricao.Name = "txtDescricao";
            this.txtDescricao.Size = new System.Drawing.Size(350, 169);
            this.txtDescricao.TabIndex = 11;
            this.txtDescricao.TextChanged += new System.EventHandler(this.textBox6_TextChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(6, 34);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(75, 20);
            this.label9.TabIndex = 10;
            this.label9.Text = "Descrição";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(469, 152);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(88, 20);
            this.label8.TabIndex = 14;
            this.label8.Text = "Fornecedor";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // cboIdFornecedor
            // 
            this.cboIdFornecedor.FormattingEnabled = true;
            this.cboIdFornecedor.Location = new System.Drawing.Point(469, 175);
            this.cboIdFornecedor.Name = "cboIdFornecedor";
            this.cboIdFornecedor.Size = new System.Drawing.Size(182, 28);
            this.cboIdFornecedor.TabIndex = 9;
            this.cboIdFornecedor.SelectedIndexChanged += new System.EventHandler(this.cboIdFornecedor_SelectedIndexChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(469, 98);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(121, 20);
            this.label7.TabIndex = 12;
            this.label7.Text = "Nivel de Serviço";
            // 
            // cboIdNivelServico
            // 
            this.cboIdNivelServico.FormattingEnabled = true;
            this.cboIdNivelServico.Location = new System.Drawing.Point(469, 121);
            this.cboIdNivelServico.Name = "cboIdNivelServico";
            this.cboIdNivelServico.Size = new System.Drawing.Size(182, 28);
            this.cboIdNivelServico.TabIndex = 8;
            this.cboIdNivelServico.TabStop = false;
            this.cboIdNivelServico.SelectedIndexChanged += new System.EventHandler(this.cboIdNivelServico_SelectedIndexChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(469, 34);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(75, 20);
            this.label6.TabIndex = 10;
            this.label6.Text = "Categoria";
            // 
            // cboIdCategoria
            // 
            this.cboIdCategoria.FormattingEnabled = true;
            this.cboIdCategoria.Location = new System.Drawing.Point(469, 57);
            this.cboIdCategoria.Name = "cboIdCategoria";
            this.cboIdCategoria.Size = new System.Drawing.Size(182, 28);
            this.cboIdCategoria.TabIndex = 7;
            this.cboIdCategoria.SelectedIndexChanged += new System.EventHandler(this.cboIdCategoria_SelectedIndexChanged);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.btnFechar);
            this.groupBox3.Controls.Add(this.btnExcluir);
            this.groupBox3.Controls.Add(this.btnLimpar);
            this.groupBox3.Controls.Add(this.btnPesquisar);
            this.groupBox3.Controls.Add(this.btnAlterar);
            this.groupBox3.Controls.Add(this.btnSalvar);
            this.groupBox3.Location = new System.Drawing.Point(12, 637);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(806, 101);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            // 
            // btnFechar
            // 
            this.btnFechar.Location = new System.Drawing.Point(657, 19);
            this.btnFechar.Name = "btnFechar";
            this.btnFechar.Size = new System.Drawing.Size(124, 53);
            this.btnFechar.TabIndex = 5;
            this.btnFechar.Text = "Fechar";
            this.btnFechar.UseVisualStyleBackColor = true;
            this.btnFechar.Click += new System.EventHandler(this.btnFechar_Click);
            // 
            // btnExcluir
            // 
            this.btnExcluir.Location = new System.Drawing.Point(527, 19);
            this.btnExcluir.Name = "btnExcluir";
            this.btnExcluir.Size = new System.Drawing.Size(124, 53);
            this.btnExcluir.TabIndex = 4;
            this.btnExcluir.Text = "Excluir";
            this.btnExcluir.UseVisualStyleBackColor = true;
            this.btnExcluir.Click += new System.EventHandler(this.btnExcluir_Click);
            // 
            // btnLimpar
            // 
            this.btnLimpar.Location = new System.Drawing.Point(397, 19);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(124, 53);
            this.btnLimpar.TabIndex = 3;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // btnPesquisar
            // 
            this.btnPesquisar.Location = new System.Drawing.Point(267, 19);
            this.btnPesquisar.Name = "btnPesquisar";
            this.btnPesquisar.Size = new System.Drawing.Size(124, 53);
            this.btnPesquisar.TabIndex = 2;
            this.btnPesquisar.Text = "Pesquisar";
            this.btnPesquisar.UseVisualStyleBackColor = true;
            this.btnPesquisar.Click += new System.EventHandler(this.btnPesquisar_Click);
            // 
            // btnAlterar
            // 
            this.btnAlterar.Location = new System.Drawing.Point(137, 19);
            this.btnAlterar.Name = "btnAlterar";
            this.btnAlterar.Size = new System.Drawing.Size(124, 53);
            this.btnAlterar.TabIndex = 1;
            this.btnAlterar.Text = "Alterar";
            this.btnAlterar.UseVisualStyleBackColor = true;
            this.btnAlterar.Click += new System.EventHandler(this.btnAlterar_Click);
            // 
            // btnSalvar
            // 
            this.btnSalvar.Location = new System.Drawing.Point(7, 19);
            this.btnSalvar.Name = "btnSalvar";
            this.btnSalvar.Size = new System.Drawing.Size(124, 53);
            this.btnSalvar.TabIndex = 0;
            this.btnSalvar.Text = "Salvar";
            this.btnSalvar.UseVisualStyleBackColor = true;
            this.btnSalvar.Click += new System.EventHandler(this.btnSalvar_Click);
            // 
            // produto
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(925, 729);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "produto";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "produto";
            this.Load += new System.EventHandler(this.produto_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private GroupBox groupBox1;
        private TextBox txtCa;
        private Label label5;
        private TextBox txtPcAquisicao;
        private Label label4;
        private TextBox txtCustoAquisicao;
        private Label label3;
        private TextBox txtCustoPedido;
        private Label label2;
        private TextBox txtNome;
        private Label label1;
        private GroupBox groupBox2;
        private Label label8;
        private ComboBox cboIdFornecedor;
        private Label label7;
        private ComboBox cboIdNivelServico;
        private Label label6;
        private ComboBox cboIdCategoria;
        private GroupBox groupBox3;
        private Button btnLimpar;
        private Button btnPesquisar;
        private Button btnAlterar;
        private Button btnSalvar;
        private TextBox txtDescricao;
        private Label label9;
        private Button btnFechar;
        private Button btnExcluir;
        private TextBox txtPcArmazenagem;
        private Label label12;
        private Label label11;
        private ComboBox cboStatus;
        private TextBox txtObs;
        private Label label10;
        private Label label13;
        private TextBox txtId;
        private ComboBox cboValorCat;
        private ComboBox cbValorFornecedor;
        private ComboBox cbValorNV;
    }
}