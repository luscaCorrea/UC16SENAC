﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Data.SqlClient;
using System.Data;

namespace sistema
{
    public class ConexaoMySql
    {
        private MySqlConnection objConexao = new MySqlConnection();
        private MySqlCommand objComandos = new MySqlCommand();
        private MySqlDataReader objDados;
        private MySqlDataAdapter objDadosEmMemoria;
        private string msgErro;
        private string strDeConexao;

        public ConexaoMySql(string server, string dataBase, string user, string password)
        {
            strDeConexao = "Server=" + server + ";";
            strDeConexao += "Database=" + dataBase + ";";
            strDeConexao += "User=" + user + ";";
            strDeConexao += "Pwd=" + password + ";";
        }


        public string getMsgErro()
        {
            return this.msgErro;
        }

        private bool conectar()
        {
            try
            {
                desconectar();
                objConexao.ConnectionString = strDeConexao;
                objComandos.Connection = objConexao;
                objConexao.Open();
                return true;
            }
            catch (Exception erro)
            {
                msgErro = erro.Message.ToString();
                return false;
            }
        }

        private bool desconectar()
        {
            try
            {
                if (objConexao.State == ConnectionState.Open)
                {
                    objConexao.Close();
                }
                return true;
            }
            catch (Exception erro)
            {
                this.msgErro = erro.Message.ToString();
                return false;
            }
        }


        public bool testarConexao()
        {
            return conectar();
        }

        public bool INSERT(string comandoSql)
        {
            try
            {
                bool blnRetorno = false;
                if (this.conectar())
                {
                    objComandos.CommandText = comandoSql;
                    int result = objComandos.ExecuteNonQuery();
                    if (result > 0)
                    {
                        blnRetorno = true;
                    }
                    else
                    {
                        msgErro = "Erro na inclusão de dados";
                    }
                }
                return blnRetorno;
            }
            catch (Exception erro)
            {
                msgErro = erro.Message.ToString();
                return false;
            }
        }

        public bool UPDATE(string comandoSql)
        {
            try
            {
                bool blnRetorno = false;
                if (conectar())
                {
                    objComandos.CommandText = comandoSql;
                    int result = objComandos.ExecuteNonQuery();
                    if (result > 0)
                    {
                        blnRetorno = true;
                    }
                    else
                    {
                        msgErro = "Erro na alteração de dados";
                    }
                }
                return blnRetorno;
            }
            catch (Exception erro)
            {
                msgErro = erro.Message.ToString();
                return false;
            }
        }

        public bool DELETE(string comandoSql)
        {
            try
            {
                bool blnRetorno = false;
                if (conectar())
                {
                    objComandos.CommandText = comandoSql;
                    int result = objComandos.ExecuteNonQuery();
                    if (result > 0)
                    {
                        blnRetorno = true;
                    }
                    else
                    {
                        msgErro = "Erro na exclusão de dados";
                    }
                }
                return blnRetorno;
            }
            catch (Exception erro)
            {
                msgErro = erro.Message.ToString();
                return false;
            }
        }

        public string[,] SELECT_1(string comandoSql)
        {
            try
            {
                string[,] result = null;
                if (conectar())
                {
                    objDadosEmMemoria = new MySqlDataAdapter(comandoSql, objConexao);
                    DataTable tabelaDeDados = new DataTable();
                    objDadosEmMemoria.Fill(tabelaDeDados);
                    if (tabelaDeDados.Rows.Count > 0)
                    {
                        int i = tabelaDeDados.Rows.Count;
                        int c = tabelaDeDados.Columns.Count;
                        result = new string[i, c];
                        DataRow[] linhas = tabelaDeDados.Select();
                        int count = 0;
                        foreach (DataRow linha in linhas)
                        {
                            for (int j = 0; j < c; j++)
                            {
                                result[count, j] = linha[j].ToString();
                            }
                            count++;
                        }
                    }
                }
                return result;

            }
            catch (Exception erro)
            {
                msgErro = erro.Message.ToString();
                return null;
            }
        }

        public DataTable SELECT_2(string comandoSql)
        {
            try
            {
                if (conectar())
                {
                    objDadosEmMemoria = new MySqlDataAdapter(comandoSql, objConexao);
                    DataTable tabelaDeDados = new DataTable();
                    objDadosEmMemoria.Fill(tabelaDeDados);
                    if (tabelaDeDados.Rows.Count > 0)
                    {
                        return tabelaDeDados;
                    }
                }
                return null;
            }
            catch (Exception erro)
            {
                msgErro = erro.Message.ToString();
                return null;
            }
        }
    }
}

namespace sistema
{
    public class ConexaoSQLServer
    {
        private SqlConnection objConexao = new SqlConnection();
        private SqlCommand objComandos = new SqlCommand();
        private SqlDataReader objDados;
        private SqlDataAdapter objDadosEmMemoria;
        private string msgErro;
        private string strDeConexao;

        public ConexaoSQLServer(string strConexao)
        {
            this.strDeConexao = strConexao;
        }

        public string getMsgErro()
        {
            return this.msgErro;
        }

        private bool conectar()
        {
            try
            {
                desconectar();
                objConexao.ConnectionString = strDeConexao;
                objComandos.Connection = objConexao;
                objConexao.Open();
                return true;
            }
            catch (Exception erro)
            {
                msgErro = erro.Message.ToString();
                return false;
            }
        }

        private bool desconectar()
        {
            try
            {
                if (objConexao.State == ConnectionState.Open)
                {
                    objConexao.Close();
                }
                return true;
            }
            catch (Exception erro)
            {
                this.msgErro = erro.Message.ToString();
                return false;
            }
        }


        public bool testarConexao()
        {
            return conectar();
        }

        public bool INSERT(string comandoSql)
        {
            try
            {
                bool blnRetorno = false;
                if (this.conectar())
                {
                    objComandos.CommandText = comandoSql;
                    int result = objComandos.ExecuteNonQuery();
                    if (result > 0)
                    {
                        blnRetorno = true;
                    }
                    else
                    {
                        msgErro = "Erro na inclusão de dados";
                    }
                }
                return blnRetorno;
            }
            catch (Exception erro)
            {
                msgErro = erro.Message.ToString();
                return false;
            }
        }

        public bool UPDATE(string comandoSql)
        {
            try
            {
                bool blnRetorno = false;
                if (conectar())
                {
                    objComandos.CommandText = comandoSql;
                    int result = objComandos.ExecuteNonQuery();
                    if (result > 0)
                    {
                        blnRetorno = true;
                    }
                    else
                    {
                        msgErro = "Erro na alteração de dados";
                    }
                }
                return blnRetorno;
            }
            catch (Exception erro)
            {
                msgErro = erro.Message.ToString();
                return false;
            }
        }

        public bool DELETE(string comandoSql)
        {
            try
            {
                bool blnRetorno = false;
                if (conectar())
                {
                    objComandos.CommandText = comandoSql;
                    int result = objComandos.ExecuteNonQuery();
                    if (result > 0)
                    {
                        blnRetorno = true;
                    }
                    else
                    {
                        msgErro = "Erro na exclusão de dados";
                    }
                }
                return blnRetorno;
            }
            catch (Exception erro)
            {
                msgErro = erro.Message.ToString();
                return false;
            }
        }

        public string[,] SELECT_1(string comandoSql)
        {
            try
            {
                string[,] result = null;
                if (conectar())
                {
                    objDadosEmMemoria = new SqlDataAdapter(comandoSql, objConexao);
                    DataTable tabelaDeDados = new DataTable();
                    objDadosEmMemoria.Fill(tabelaDeDados);
                    if (tabelaDeDados.Rows.Count > 0)
                    {
                        int i = tabelaDeDados.Rows.Count;
                        int c = tabelaDeDados.Columns.Count;
                        result = new string[i, c];
                        DataRow[] linhas = tabelaDeDados.Select();
                        int count = 0;
                        foreach (DataRow linha in linhas)
                        {
                            for (int j = 0; j < c; j++)
                            {
                                result[count, j] = linha[j].ToString();
                            }
                            count++;
                        }
                    }
                }
                return result;

            }
            catch (Exception erro)
            {
                msgErro = erro.Message.ToString();
                return null;
            }
        }

        public DataTable SELECT_2(string comandoSql)
        {
            try
            {
                if (conectar())
                {
                    objDadosEmMemoria = new SqlDataAdapter(comandoSql, objConexao);
                    DataTable tabelaDeDados = new DataTable();
                    objDadosEmMemoria.Fill(tabelaDeDados);
                    if (tabelaDeDados.Rows.Count > 0)
                    {
                        return tabelaDeDados;
                    }
                }
                return null;
            }
            catch (Exception erro)
            {
                msgErro = erro.Message.ToString();
                return null;
            }
        }
    }
}
