using System;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Windows.Forms;

namespace SistemaCalculo
{
    public partial class SistemaCalculo : Form
    {
        public SistemaCalculo()
        {
            InitializeComponent();
        }

        string strConexao = "" +
                "Data Source=10.37.45.37;" +
                "Initial Catalog=sistema;" +
                "User ID=sa;" +
                "Password=123456";

        private void conexao()
        {
            SqlConnection conn = new SqlConnection(strConexao);

            try
            {
                conn.Open();
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro " + ex.ToString());
                Application.Exit();
            }
        }

        private void txtMes1_TextChanged(object sender, EventArgs e) { }

        private void txtMes2_TextChanged(object sender, EventArgs e) { }

        private void txtMes3_TextChanged(object sender, EventArgs e) { }

        private void txtMes4_TextChanged(object sender, EventArgs e) { }

        private void txtMes5_TextChanged(object sender, EventArgs e) { }

        private void txtMes6_TextChanged(object sender, EventArgs e) { }

        private void lblMedia_Click(object sender, EventArgs e) { }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double n1 = double.Parse(txtMes1.Text);
            double n2 = double.Parse(txtMes2.Text);
            double n3 = double.Parse(txtMes3.Text);
            double n4 = double.Parse(txtMes4.Text);
            double n5 = double.Parse(txtMes5.Text);
            double n6 = double.Parse(txtMes6.Text);

            double[] data = { n1, n2, n3, n4, n5, n6 };
            double mean = data.Average();

            lblMedia.Text = mean.ToString();
            string formatado2 = $"{mean:F2}";
            lblMedia.Text = formatado2.ToString();

            double SomaDosQuadrados = data.Select(val => (val - mean) * (val - mean)).Sum();
            double DesvioPadrao = Math.Sqrt(SomaDosQuadrados / (data.Length - 1));

            string sql = "select * from fornecedor where id_fornecedor = " + txtId.Text;

            SqlConnection conexao = new SqlConnection(strConexao);
            SqlCommand cmd = new SqlCommand(sql, conexao);
            cmd.CommandType = CommandType.Text;
            SqlDataReader reader;
            conexao.Open();

            double fatorSeguranca = 1;
            double sku = 1;

            try
            {
                reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    string a1 = reader[5].ToString(); //SKU
                    sku = double.Parse(a1);
                }
                else
                {
                    MessageBox.Show("C�digo do fornecedor inexistente!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                conexao.Close();
            }

            double ppValue = pp(mean, sku);



            string sql2 = "select * from nivel_de_servico where id_nivel_servico =" + txtId.Text;

            SqlConnection conexao2 = new SqlConnection(strConexao);
            SqlCommand cmd2 = new SqlCommand(sql2, conexao2);
            cmd2.CommandType = CommandType.Text;
            SqlDataReader reader2;
            conexao2.Open();

            try
            {
                reader2 = cmd2.ExecuteReader();
                if (reader2.Read())
                {
                    string a2 = reader2[2].ToString(); //fator seguran�a
                    fatorSeguranca = double.Parse(a2);
                }
                else
                {
                    MessageBox.Show("C�digo de n�vel de servi�o inexistente!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                conexao2.Close();
            }

            double estoqueS = es(fatorSeguranca, DesvioPadrao, sku, ppValue);
            string formatado = $"{estoqueS:F2}";

            lblEstoque.Text = formatado.ToString();


        }

        private double pp(double media, double sku)
        {
            return media * sku;
        }

        private double es(double fatorSeguranca, double sku, double desvioP, double pp)
        {
            return fatorSeguranca * desvioP * Math.Sqrt(sku / pp);
        }

        private void lblEstoque_Click(object sender, EventArgs e)
        {

        }

        private void btnPesquisar_Click(object sender, EventArgs e)
        {
            string sql2 = "select * from nivel_de_servico where id_nivel_servico =" + txtId.Text;

            SqlConnection conexao2 = new SqlConnection(strConexao);
            SqlCommand cmd2 = new SqlCommand(sql2, conexao2);
            cmd2.CommandType = CommandType.Text;
            SqlDataReader reader2;
            conexao2.Open();

            try
            {
                reader2 = cmd2.ExecuteReader();
                if (reader2.Read())
                {
                    txtNivelServico.Text = reader2[2].ToString();
                }
                else
                {
                    MessageBox.Show("C�digo de n�vel de servi�o inexistente!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                conexao2.Close();
            }

            ////////////////////////////////////////////////////////////////////////////////////////////
            ///

            string sql = "select * from fornecedor where id_fornecedor = " + txtId.Text;

            SqlConnection conexao = new SqlConnection(strConexao);
            SqlCommand cmd = new SqlCommand(sql, conexao);
            cmd.CommandType = CommandType.Text;
            SqlDataReader reader;
            conexao.Open();

            double fatorSeguranca = 1;
            double sku = 1;

            try
            {
                reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    txtfornecedor.Text = reader[5].ToString();
                    
                }
                else
                {
                    MessageBox.Show("C�digo do fornecedor inexistente!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                conexao.Close();
            }
        }
    }
}
