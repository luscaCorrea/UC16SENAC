﻿namespace SistemaCalculo
{
    partial class SistemaCalculo
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCalcular = new System.Windows.Forms.Button();
            this.txtMes1 = new System.Windows.Forms.TextBox();
            this.txtMes2 = new System.Windows.Forms.TextBox();
            this.txtMes3 = new System.Windows.Forms.TextBox();
            this.txtMes4 = new System.Windows.Forms.TextBox();
            this.txtMes5 = new System.Windows.Forms.TextBox();
            this.txtMes6 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lblMedia = new System.Windows.Forms.Label();
            this.txtId = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.lblEstoque = new System.Windows.Forms.Label();
            this.txtNivelServico = new System.Windows.Forms.TextBox();
            this.txtfornecedor = new System.Windows.Forms.TextBox();
            this.btnPesquisar = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnCalcular
            // 
            this.btnCalcular.Location = new System.Drawing.Point(246, 478);
            this.btnCalcular.Margin = new System.Windows.Forms.Padding(4);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(327, 84);
            this.btnCalcular.TabIndex = 0;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // txtMes1
            // 
            this.txtMes1.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtMes1.Location = new System.Drawing.Point(10, 97);
            this.txtMes1.Margin = new System.Windows.Forms.Padding(4);
            this.txtMes1.Name = "txtMes1";
            this.txtMes1.Size = new System.Drawing.Size(127, 33);
            this.txtMes1.TabIndex = 1;
            this.txtMes1.TextChanged += new System.EventHandler(this.txtMes1_TextChanged);
            // 
            // txtMes2
            // 
            this.txtMes2.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtMes2.Location = new System.Drawing.Point(147, 97);
            this.txtMes2.Margin = new System.Windows.Forms.Padding(4);
            this.txtMes2.Name = "txtMes2";
            this.txtMes2.Size = new System.Drawing.Size(127, 33);
            this.txtMes2.TabIndex = 2;
            this.txtMes2.TextChanged += new System.EventHandler(this.txtMes2_TextChanged);
            // 
            // txtMes3
            // 
            this.txtMes3.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtMes3.Location = new System.Drawing.Point(283, 97);
            this.txtMes3.Margin = new System.Windows.Forms.Padding(4);
            this.txtMes3.Name = "txtMes3";
            this.txtMes3.Size = new System.Drawing.Size(127, 33);
            this.txtMes3.TabIndex = 3;
            this.txtMes3.TextChanged += new System.EventHandler(this.txtMes3_TextChanged);
            // 
            // txtMes4
            // 
            this.txtMes4.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtMes4.Location = new System.Drawing.Point(419, 97);
            this.txtMes4.Margin = new System.Windows.Forms.Padding(4);
            this.txtMes4.Name = "txtMes4";
            this.txtMes4.Size = new System.Drawing.Size(127, 33);
            this.txtMes4.TabIndex = 4;
            this.txtMes4.TextChanged += new System.EventHandler(this.txtMes4_TextChanged);
            // 
            // txtMes5
            // 
            this.txtMes5.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtMes5.Location = new System.Drawing.Point(555, 97);
            this.txtMes5.Margin = new System.Windows.Forms.Padding(4);
            this.txtMes5.Name = "txtMes5";
            this.txtMes5.Size = new System.Drawing.Size(127, 33);
            this.txtMes5.TabIndex = 5;
            this.txtMes5.TextChanged += new System.EventHandler(this.txtMes5_TextChanged);
            // 
            // txtMes6
            // 
            this.txtMes6.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtMes6.Location = new System.Drawing.Point(692, 97);
            this.txtMes6.Margin = new System.Windows.Forms.Padding(4);
            this.txtMes6.Name = "txtMes6";
            this.txtMes6.Size = new System.Drawing.Size(136, 33);
            this.txtMes6.TabIndex = 6;
            this.txtMes6.TextChanged += new System.EventHandler(this.txtMes6_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(10, 71);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(17, 21);
            this.label1.TabIndex = 7;
            this.label1.Text = "1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(147, 71);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(18, 21);
            this.label2.TabIndex = 8;
            this.label2.Text = "2";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(283, 71);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(18, 21);
            this.label3.TabIndex = 9;
            this.label3.Text = "3";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.label4.Location = new System.Drawing.Point(419, 71);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(19, 21);
            this.label4.TabIndex = 10;
            this.label4.Text = "4";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.label5.Location = new System.Drawing.Point(555, 71);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(18, 21);
            this.label5.TabIndex = 11;
            this.label5.Text = "5";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.label6.Location = new System.Drawing.Point(692, 71);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(19, 21);
            this.label6.TabIndex = 12;
            this.label6.Text = "6";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label7.Location = new System.Drawing.Point(13, 35);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(184, 25);
            this.label7.TabIndex = 13;
            this.label7.Text = "Demanada por mês:";
            // 
            // lblMedia
            // 
            this.lblMedia.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.lblMedia.Font = new System.Drawing.Font("Segoe UI Semibold", 22F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.lblMedia.Location = new System.Drawing.Point(10, 145);
            this.lblMedia.Name = "lblMedia";
            this.lblMedia.Size = new System.Drawing.Size(818, 83);
            this.lblMedia.TabIndex = 14;
            this.lblMedia.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblMedia.Click += new System.EventHandler(this.lblMedia_Click);
            // 
            // txtId
            // 
            this.txtId.Location = new System.Drawing.Point(419, 277);
            this.txtId.Name = "txtId";
            this.txtId.Size = new System.Drawing.Size(115, 29);
            this.txtId.TabIndex = 15;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.label8.Location = new System.Drawing.Point(381, 280);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(31, 21);
            this.label8.TabIndex = 16;
            this.label8.Text = "ID:";
            // 
            // lblEstoque
            // 
            this.lblEstoque.BackColor = System.Drawing.Color.Aqua;
            this.lblEstoque.Font = new System.Drawing.Font("Segoe UI Semibold", 22F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.lblEstoque.Location = new System.Drawing.Point(10, 343);
            this.lblEstoque.Name = "lblEstoque";
            this.lblEstoque.Size = new System.Drawing.Size(818, 83);
            this.lblEstoque.TabIndex = 17;
            this.lblEstoque.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblEstoque.Click += new System.EventHandler(this.lblEstoque_Click);
            // 
            // txtNivelServico
            // 
            this.txtNivelServico.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtNivelServico.Location = new System.Drawing.Point(13, 277);
            this.txtNivelServico.Margin = new System.Windows.Forms.Padding(4);
            this.txtNivelServico.Name = "txtNivelServico";
            this.txtNivelServico.Size = new System.Drawing.Size(127, 33);
            this.txtNivelServico.TabIndex = 18;
            // 
            // txtfornecedor
            // 
            this.txtfornecedor.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtfornecedor.Location = new System.Drawing.Point(174, 277);
            this.txtfornecedor.Margin = new System.Windows.Forms.Padding(4);
            this.txtfornecedor.Name = "txtfornecedor";
            this.txtfornecedor.Size = new System.Drawing.Size(127, 33);
            this.txtfornecedor.TabIndex = 19;
            // 
            // btnPesquisar
            // 
            this.btnPesquisar.Location = new System.Drawing.Point(624, 248);
            this.btnPesquisar.Name = "btnPesquisar";
            this.btnPesquisar.Size = new System.Drawing.Size(149, 84);
            this.btnPesquisar.TabIndex = 20;
            this.btnPesquisar.Text = "Pesquisar";
            this.btnPesquisar.UseVisualStyleBackColor = true;
            this.btnPesquisar.Click += new System.EventHandler(this.btnPesquisar_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.label9.Location = new System.Drawing.Point(174, 248);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(89, 21);
            this.label9.TabIndex = 21;
            this.label9.Text = "Fornecedor";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.label10.Location = new System.Drawing.Point(13, 252);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(123, 21);
            this.label10.TabIndex = 22;
            this.label10.Text = "Nivel de serviço";
            // 
            // SistemaCalculo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(844, 649);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.btnPesquisar);
            this.Controls.Add(this.txtfornecedor);
            this.Controls.Add(this.txtNivelServico);
            this.Controls.Add(this.lblEstoque);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txtId);
            this.Controls.Add(this.lblMedia);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtMes6);
            this.Controls.Add(this.txtMes5);
            this.Controls.Add(this.txtMes4);
            this.Controls.Add(this.txtMes3);
            this.Controls.Add(this.txtMes2);
            this.Controls.Add(this.txtMes1);
            this.Controls.Add(this.btnCalcular);
            this.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "SistemaCalculo";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Button btnCalcular;
        private TextBox txtMes1;
        private TextBox txtMes2;
        private TextBox txtMes3;
        private TextBox txtMes4;
        private TextBox txtMes5;
        private TextBox txtMes6;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label lblMedia;
        private TextBox txtId;
        private Label label8;
        private Label lblEstoque;
        private TextBox txtNivelServico;
        private TextBox txtfornecedor;
        private Button btnPesquisar;
        private Label label9;
        private Label label10;
    }
}