﻿namespace CEstoque
{
    partial class FormProduto
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblCodigo = new System.Windows.Forms.Label();
            this.lblDescricao = new System.Windows.Forms.Label();
            this.lblCodigoBarras = new System.Windows.Forms.Label();
            this.lblNivelServico = new System.Windows.Forms.Label();
            this.txtCodigo = new System.Windows.Forms.TextBox();
            this.txtDescricao = new System.Windows.Forms.TextBox();
            this.txtCodigoBarras = new System.Windows.Forms.TextBox();
            this.txtNivelServico = new System.Windows.Forms.TextBox();
            this.btnSalvarProduto = new System.Windows.Forms.Button();
            this.btnImportarDemanda = new System.Windows.Forms.Button();
            this.ofdImportarDemanda = new System.Windows.Forms.OpenFileDialog();
            this.button1 = new System.Windows.Forms.Button();
            this.btnGerarPDF = new System.Windows.Forms.Button();
            this.btnGerarTodosPDF = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblCodigo
            // 
            this.lblCodigo.AutoSize = true;
            this.lblCodigo.Location = new System.Drawing.Point(52, 62);
            this.lblCodigo.Name = "lblCodigo";
            this.lblCodigo.Size = new System.Drawing.Size(58, 20);
            this.lblCodigo.TabIndex = 0;
            this.lblCodigo.Text = "Código";
            this.lblCodigo.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblDescricao
            // 
            this.lblDescricao.AutoSize = true;
            this.lblDescricao.Location = new System.Drawing.Point(52, 95);
            this.lblDescricao.Name = "lblDescricao";
            this.lblDescricao.Size = new System.Drawing.Size(74, 20);
            this.lblDescricao.TabIndex = 1;
            this.lblDescricao.Text = "Descrição";
            // 
            // lblCodigoBarras
            // 
            this.lblCodigoBarras.AutoSize = true;
            this.lblCodigoBarras.Location = new System.Drawing.Point(52, 133);
            this.lblCodigoBarras.Name = "lblCodigoBarras";
            this.lblCodigoBarras.Size = new System.Drawing.Size(124, 20);
            this.lblCodigoBarras.TabIndex = 2;
            this.lblCodigoBarras.Text = "Código de Barras";
            // 
            // lblNivelServico
            // 
            this.lblNivelServico.AutoSize = true;
            this.lblNivelServico.Location = new System.Drawing.Point(52, 163);
            this.lblNivelServico.Name = "lblNivelServico";
            this.lblNivelServico.Size = new System.Drawing.Size(116, 20);
            this.lblNivelServico.TabIndex = 3;
            this.lblNivelServico.Text = "Nível de Serviço";
            // 
            // txtCodigo
            // 
            this.txtCodigo.Location = new System.Drawing.Point(182, 62);
            this.txtCodigo.Name = "txtCodigo";
            this.txtCodigo.Size = new System.Drawing.Size(201, 27);
            this.txtCodigo.TabIndex = 4;
            // 
            // txtDescricao
            // 
            this.txtDescricao.Location = new System.Drawing.Point(182, 95);
            this.txtDescricao.Name = "txtDescricao";
            this.txtDescricao.Size = new System.Drawing.Size(201, 27);
            this.txtDescricao.TabIndex = 5;
            // 
            // txtCodigoBarras
            // 
            this.txtCodigoBarras.Location = new System.Drawing.Point(182, 128);
            this.txtCodigoBarras.Name = "txtCodigoBarras";
            this.txtCodigoBarras.Size = new System.Drawing.Size(201, 27);
            this.txtCodigoBarras.TabIndex = 6;
            // 
            // txtNivelServico
            // 
            this.txtNivelServico.Location = new System.Drawing.Point(182, 160);
            this.txtNivelServico.Name = "txtNivelServico";
            this.txtNivelServico.Size = new System.Drawing.Size(201, 27);
            this.txtNivelServico.TabIndex = 7;
            // 
            // btnSalvarProduto
            // 
            this.btnSalvarProduto.Location = new System.Drawing.Point(105, 249);
            this.btnSalvarProduto.Name = "btnSalvarProduto";
            this.btnSalvarProduto.Size = new System.Drawing.Size(145, 60);
            this.btnSalvarProduto.TabIndex = 8;
            this.btnSalvarProduto.Text = "Salvar";
            this.btnSalvarProduto.UseVisualStyleBackColor = true;
            this.btnSalvarProduto.Click += new System.EventHandler(this.btnSalvarProduto_Click);
            // 
            // btnImportarDemanda
            // 
            this.btnImportarDemanda.Location = new System.Drawing.Point(281, 249);
            this.btnImportarDemanda.Name = "btnImportarDemanda";
            this.btnImportarDemanda.Size = new System.Drawing.Size(145, 60);
            this.btnImportarDemanda.TabIndex = 9;
            this.btnImportarDemanda.Text = "Importar";
            this.btnImportarDemanda.UseVisualStyleBackColor = true;
            this.btnImportarDemanda.Click += new System.EventHandler(this.btnImportarDemanda_Click);
            // 
            // ofdImportarDemanda
            // 
            this.ofdImportarDemanda.FileName = "openFileDialog1";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(451, 249);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(145, 60);
            this.button1.TabIndex = 10;
            this.button1.Text = "Parâmetros";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnGerarPDF
            // 
            this.btnGerarPDF.Location = new System.Drawing.Point(628, 249);
            this.btnGerarPDF.Name = "btnGerarPDF";
            this.btnGerarPDF.Size = new System.Drawing.Size(145, 60);
            this.btnGerarPDF.TabIndex = 11;
            this.btnGerarPDF.Text = "Gerar Código de Barras (item)";
            this.btnGerarPDF.UseVisualStyleBackColor = true;
            this.btnGerarPDF.Click += new System.EventHandler(this.btnGerarPDF_Click);
            // 
            // btnGerarTodosPDF
            // 
            this.btnGerarTodosPDF.Location = new System.Drawing.Point(345, 331);
            this.btnGerarTodosPDF.Name = "btnGerarTodosPDF";
            this.btnGerarTodosPDF.Size = new System.Drawing.Size(195, 60);
            this.btnGerarTodosPDF.TabIndex = 12;
            this.btnGerarTodosPDF.Text = "Gerar Códigos de Barras (Todos os Produtos)";
            this.btnGerarTodosPDF.UseVisualStyleBackColor = true;
            this.btnGerarTodosPDF.Click += new System.EventHandler(this.btnGerarTodosPDF_Click);
            // 
            // FormProduto
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(871, 423);
            this.Controls.Add(this.btnGerarTodosPDF);
            this.Controls.Add(this.btnGerarPDF);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnImportarDemanda);
            this.Controls.Add(this.btnSalvarProduto);
            this.Controls.Add(this.txtNivelServico);
            this.Controls.Add(this.txtCodigoBarras);
            this.Controls.Add(this.txtDescricao);
            this.Controls.Add(this.txtCodigo);
            this.Controls.Add(this.lblNivelServico);
            this.Controls.Add(this.lblCodigoBarras);
            this.Controls.Add(this.lblDescricao);
            this.Controls.Add(this.lblCodigo);
            this.Name = "FormProduto";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.FormProduto_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label lblCodigo;
        private Label lblDescricao;
        private Label lblCodigoBarras;
        private Label lblNivelServico;
        private TextBox txtCodigo;
        private TextBox txtDescricao;
        private TextBox txtCodigoBarras;
        private TextBox txtNivelServico;
        private Button btnSalvarProduto;
        private Button btnImportarDemanda;
        private OpenFileDialog ofdImportarDemanda;
        private Button button1;
        private Button btnGerarPDF;
        private Button btnGerarTodosPDF;
    }
}