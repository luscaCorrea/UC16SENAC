﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace CEstoque
{
    public partial class FormCalculoEstoque : Form
    {
        // Defina a string de conexão aqui
        private string connectionString = "Server=localhost;Database=EstoqueDB;User Id=sa;Password=123456;";

        public FormCalculoEstoque()
        {
            InitializeComponent();
        }

        private void btnCalcularEstoque_Click(object sender, EventArgs e)
        {
            string codigoBarras = txtProdutoId.Text;
            List<int> demandas = new List<int>();
            float nivelServico = 0;
            int produtoId = 0;

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("SELECT Id, NivelServico FROM Produtos WHERE CodigoBarras = @CodigoBarras", conn);
                cmd.Parameters.AddWithValue("@CodigoBarras", codigoBarras);
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    produtoId = reader.GetInt32(0);
                    nivelServico = Convert.ToSingle(reader.GetDouble(1));
                    reader.Close();

                    cmd = new SqlCommand("SELECT Quantidade FROM Demanda WHERE ProdutoId = @ProdutoId", conn);
                    cmd.Parameters.AddWithValue("@ProdutoId", produtoId);
                    reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        demandas.Add(reader.GetInt32(0));
                    }
                }
                else
                {
                    MessageBox.Show("Produto não encontrado.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
            }

            // Cálculos
            double mediaDemanda = demandas.Average();
            double desvioPadraoDemanda = Math.Sqrt(demandas.Average(v => Math.Pow(v - mediaDemanda, 2)));
            double estoqueSeguranca = desvioPadraoDemanda * nivelServico;
            double estoqueMaximo = mediaDemanda + estoqueSeguranca;
            double estoqueMedio = (estoqueMaximo + estoqueSeguranca) / 2;
            double pontoPedido = mediaDemanda * 2;
            double intervaloEntrePedidos = 1;
            double loteEconomico = Math.Sqrt(2 * mediaDemanda * 100 / 5);

            // Salvar parâmetros calculados no banco de dados
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("INSERT INTO ParametrosEstoque (ProdutoId, EstoqueSeguranca, EstoqueMaximo, EstoqueMedio, PontoPedido, IntervaloEntrePedidos, LoteEconomico) VALUES (@ProdutoId, @EstoqueSeguranca, @EstoqueMaximo, @EstoqueMedio, @PontoPedido, @IntervaloEntrePedidos, @LoteEconomico)", conn);
                cmd.Parameters.AddWithValue("@ProdutoId", produtoId);
                cmd.Parameters.AddWithValue("@EstoqueSeguranca", estoqueSeguranca);
                cmd.Parameters.AddWithValue("@EstoqueMaximo", estoqueMaximo);
                cmd.Parameters.AddWithValue("@EstoqueMedio", estoqueMedio);
                cmd.Parameters.AddWithValue("@PontoPedido", pontoPedido);
                cmd.Parameters.AddWithValue("@IntervaloEntrePedidos", intervaloEntrePedidos);
                cmd.Parameters.AddWithValue("@LoteEconomico", loteEconomico);
                cmd.ExecuteNonQuery();
            }

            // Mostrar resultados na tela
            txtEstoqueSeguranca.Text = estoqueSeguranca.ToString();
            txtEstoqueMaximo.Text = estoqueMaximo.ToString();
            txtEstoqueMedio.Text = estoqueMedio.ToString();
            txtPontoPedido.Text = pontoPedido.ToString();
            txtIntervaloEntrePedidos.Text = intervaloEntrePedidos.ToString();
            txtLoteEconomico.Text = loteEconomico.ToString();
        }

        private void btnExportarCSV_Click(object sender, EventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "CSV files (*.csv)|*.csv";
            if (sfd.ShowDialog() == DialogResult.OK)
            {
                using (StreamWriter sw = new StreamWriter(sfd.FileName))
                {
                    using (SqlConnection conn = new SqlConnection(connectionString))
                    {
                        conn.Open();
                        SqlCommand cmd = new SqlCommand("SELECT * FROM ParametrosEstoque", conn);
                        SqlDataReader reader = cmd.ExecuteReader();
                        while (reader.Read())
                        {
                            string linha = $"{reader["ProdutoId"]};{reader["EstoqueSeguranca"]};{reader["EstoqueMaximo"]};{reader["EstoqueMedio"]};{reader["PontoPedido"]};{reader["IntervaloEntrePedidos"]};{reader["LoteEconomico"]}";
                            sw.WriteLine(linha);
                        }
                    }
                }
            }
        }
    }
}
