using System;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Windows.Forms;
using iTextSharp.text;
using iTextSharp.text.pdf;

namespace CEstoque
{
    public partial class FormProduto : Form
    {
        // Defina a string de conex�o aqui
        private string connectionString = "Server=localhost;Database=EstoqueDB;User Id=sa;Password=123456;";

        public FormProduto()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnSalvarProduto_Click(object sender, EventArgs e)
        {
            string codigo = txtCodigo.Text;
            string descricao = txtDescricao.Text;
            string codigoBarras = txtCodigoBarras.Text;
            float nivelServico = float.Parse(txtNivelServico.Text);

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("INSERT INTO Produtos (Codigo, Descricao, CodigoBarras, NivelServico) VALUES (@Codigo, @Descricao, @CodigoBarras, @NivelServico)", conn);
                cmd.Parameters.AddWithValue("@Codigo", codigo);
                cmd.Parameters.AddWithValue("@Descricao", descricao);
                cmd.Parameters.AddWithValue("@CodigoBarras", codigoBarras);
                cmd.Parameters.AddWithValue("@NivelServico", nivelServico);
                cmd.ExecuteNonQuery();
            }
        }

        private void btnImportarDemanda_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                string[] lines = File.ReadAllLines(ofd.FileName);
                foreach (string line in lines)
                {
                    string[] data = line.Split(';'); // Mudan�a para usar separador ';'
                    int produtoId = int.Parse(data[0]);

                    // Verificar se o ProdutoId existe na tabela Produtos
                    bool produtoExiste = false;
                    using (SqlConnection conn = new SqlConnection(connectionString))
                    {
                        conn.Open();
                        SqlCommand checkCmd = new SqlCommand("SELECT COUNT(1) FROM Produtos WHERE Id = @ProdutoId", conn);
                        checkCmd.Parameters.AddWithValue("@ProdutoId", produtoId);
                        produtoExiste = (int)checkCmd.ExecuteScalar() > 0;
                    }

                    if (produtoExiste)
                    {
                        for (int i = 1; i <= 6; i++)
                        {
                            int quantidade = int.Parse(data[i]);
                            using (SqlConnection conn = new SqlConnection(connectionString))
                            {
                                conn.Open();
                                SqlCommand cmd = new SqlCommand("INSERT INTO Demanda (ProdutoId, Periodo, Quantidade) VALUES (@ProdutoId, @Periodo, @Quantidade)", conn);
                                cmd.Parameters.AddWithValue("@ProdutoId", produtoId);
                                cmd.Parameters.AddWithValue("@Periodo", i);
                                cmd.Parameters.AddWithValue("@Quantidade", quantidade);
                                cmd.ExecuteNonQuery();
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show($"ProdutoId {produtoId} n�o encontrado na tabela Produtos. A demanda n�o ser� inserida para este produto.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void btnGerarPDF_Click(object sender, EventArgs e)
        {
                    
                string codigoBarras = txtCodigoBarras.Text;
                string descricao = txtDescricao.Text;

                // Validar o c�digo de barras
                if (codigoBarras.Length != 13 || !codigoBarras.All(char.IsDigit))
                {
                    MessageBox.Show("O c�digo de barras deve ter exatamente 13 d�gitos num�ricos.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                SaveFileDialog sfd = new SaveFileDialog();
                sfd.Filter = "PDF files (*.pdf)|*.pdf";
                if (sfd.ShowDialog() == DialogResult.OK)
                {
                    using (FileStream fs = new FileStream(sfd.FileName, FileMode.Create, FileAccess.Write, FileShare.None))
                    {
                        Document doc = new Document();
                        PdfWriter writer = PdfWriter.GetInstance(doc, fs);
                        doc.Open();

                        BarcodeEAN barcode = new BarcodeEAN();
                        barcode.CodeType = Barcode.EAN13; 
                        barcode.Code = codigoBarras;

                        PdfPCell cell = new PdfPCell(barcode.CreateImageWithBarcode(writer.DirectContent, null, null));
                        cell.HorizontalAlignment = Element.ALIGN_CENTER;
                        PdfPTable table = new PdfPTable(1);
                        table.AddCell(cell);

                        cell = new PdfPCell(new Phrase(descricao));
                        cell.HorizontalAlignment = Element.ALIGN_CENTER;
                        table.AddCell(cell);

                        doc.Add(table);
                        doc.Close();
                    }
                }
            }

        private void FormProduto_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            FormCalculoEstoque param = new FormCalculoEstoque();
            param.Show();
        }

        private void btnGerarTodosPDF_Click(object sender, EventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "PDF files (*.pdf)|*.pdf";
            if (sfd.ShowDialog() == DialogResult.OK)
            {
                using (FileStream fs = new FileStream(sfd.FileName, FileMode.Create, FileAccess.Write, FileShare.None))
                {
                    Document doc = new Document();
                    PdfWriter writer = PdfWriter.GetInstance(doc, fs);
                    doc.Open();

                    PdfPTable table = new PdfPTable(1);

                    using (SqlConnection conn = new SqlConnection(connectionString))
                    {
                        conn.Open();
                        SqlCommand cmd = new SqlCommand("SELECT CodigoBarras, Descricao FROM Produtos", conn);
                        SqlDataReader reader = cmd.ExecuteReader();
                        while (reader.Read())
                        {
                            string codigoBarras = reader["CodigoBarras"].ToString().PadLeft(13, '0'); // Completar com zeros � esquerda
                            string descricao = reader["Descricao"].ToString();

                            BarcodeEAN barcode = new BarcodeEAN();
                            barcode.CodeType = Barcode.EAN13;
                            barcode.Code = codigoBarras;

                            PdfPCell cell = new PdfPCell(barcode.CreateImageWithBarcode(writer.DirectContent, null, null));
                            cell.HorizontalAlignment = Element.ALIGN_CENTER;
                            table.AddCell(cell);

                            cell = new PdfPCell(new Phrase(descricao));
                            cell.HorizontalAlignment = Element.ALIGN_CENTER;
                            table.AddCell(cell);
                        }
                        reader.Close();
                    }

                    doc.Add(table);
                    doc.Close();
                }
            }
        }
    }

        

    }

